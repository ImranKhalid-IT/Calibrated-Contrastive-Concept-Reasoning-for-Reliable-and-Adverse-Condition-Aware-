"""Assemble Tables IV-XI (and the Fig. 4 data) from stage outputs as CSV and LaTeX.

Every number written here is computed from the per-instance files in `output_dir`; nothing is
hard-coded. Missing stage outputs are skipped with a message.
"""
from __future__ import annotations

import csv

import numpy as np

from . import calibration as cal
from .adverse import MECHANISMS, MechanismScaler
from .metrics import box_agreement, contrastive_fidelity, method_deadzone, multilabel_report, role_report
from .pipeline import load, log, out_dir
from .roles import ROLES, UNDETERMINED
from .seeding import stream
from .stats import cluster_bootstrap_diff, holm

METHODS = ["gradcampp", "drise", "scorecam", "craft", "c3r"]


def _write(rows, name, cfg):
    d = out_dir(cfg) / "tables"
    d.mkdir(exist_ok=True)
    if not rows:
        return
    keys = list(rows[0])
    with open(d / f"{name}.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, keys)
        w.writeheader()
        w.writerows(rows)
    with open(d / f"{name}.tex", "w", encoding="utf-8") as f:
        f.write("\\begin{tabular}{" + "l" * len(keys) + "}\n\\toprule\n")
        f.write(" & ".join(k.replace("_", "\\_") for k in keys) + " \\\\\n\\midrule\n")
        for r in rows:
            f.write(" & ".join(_fmt(r[k]) for k in keys) + " \\\\\n")
        f.write("\\bottomrule\n\\end{tabular}\n")
    log(f"wrote tables/{name}.csv/.tex")


def _fmt(v):
    if isinstance(v, float):
        return "N/A" if not np.isfinite(v) else f"{v:.3f}"
    return str(v).replace("_", "\\_").replace("%", "\\%")


def _exists(cfg, name):
    p = out_dir(cfg) / name
    if not p.exists():
        log(f"skip: {name} not found")
        return False
    return True


# ------------------------------------------------------------------ directional audit set
def _dir_set(rows):
    keep = [r for r in rows if r["audit_valid"] and r["audit_role"] in ("supporting", "conflicting")]
    audit_dir = np.array([1 if r["audit_role"] == "supporting" else -1 for r in keep])
    return keep, audit_dir


# ------------------------------------------------------------------ Table IV
def table4(cfg):
    if not (_exists(cfg, "explain_test_full.pkl") and _exists(cfg, "baselines_test.pkl")
            and _exists(cfg, "baselines_dev.pkl")):
        return
    rows = load(out_dir(cfg) / "explain_test_full.pkl")
    keep, audit_dir = _dir_set(rows)
    bt, bd = load(out_dir(cfg) / "baselines_test.pkl"), load(out_dir(cfg) / "baselines_dev.pkl")
    idx = {(s["obj_id"], s["condition"], s["k"]): s for s in bt["scores"]}
    dev_scores = bd["scores"]
    dev_aie = np.array([s["c3r"] for s in dev_scores])
    keep2 = [(r, a) for r, a in zip(keep, audit_dir) if (r["obj_id"], r["condition"], r["k"]) in idx]
    imgs = np.array([r["image_id"] for r, _ in keep2])
    adir = np.array([a for _, a in keep2])
    iou_loss = np.array([r["audit_iou_loss"] for r, _ in keep2])
    res, correct = {}, {}
    for m in METHODS:
        sc = np.array([np.nan_to_num(idx[(r["obj_id"], r["condition"], r["k"])][m]) for r, _ in keep2])
        dE = cfg.roles.delta_M if m == "c3r" else method_deadzone(dev_aie, np.nan_to_num(
            np.array([s[m] for s in dev_scores])), cfg.roles.delta_M)
        cf, corr = contrastive_fidelity(sc, dE, adir)
        ba, _, _ = box_agreement(sc, dE, iou_loss, cfg.roles.delta_L)
        a = [x for x in bt["aucs"] if x["method"] == m]
        res[m] = {"del": float(np.mean([x["del"] for x in a])) if a else np.nan,
                  "ins": float(np.mean([x["ins"] for x in a])) if a else np.nan, "CF": cf, "BA": ba, "deadzone": dE}
        correct[m] = corr
    rng = stream("stats", "table4")
    diffs = {m: cluster_bootstrap_diff(imgs, correct["c3r"], correct[m], cfg.stats.n_boot, rng) for m in METHODS[:-1]}
    padj = holm([diffs[m][2] for m in METHODS[:-1]])
    out = []
    for i, m in enumerate(METHODS):
        r = res[m]
        d = diffs.get(m)
        out.append({"method": m, "deletion_auc": r["del"], "insertion_auc": r["ins"], "contrastive_fidelity": r["CF"],
                    "box_agreement": r["BA"], "delta_E": r["deadzone"],
                    "paired_delta_CF": "reference" if d is None else f"{d[0]:+.3f} [{d[1][0]:.3f}, {d[1][1]:.3f}]",
                    "holm_p": "" if d is None else f"{padj[i]:.4f}"})
    out.append({"method": f"n_directional_pairs={len(keep2)}", **{k: "" for k in list(out[0])[1:]}})
    _write(out, "table4_faithfulness", cfg)


# ------------------------------------------------------------------ Table V (per-pair listing)
def table5(cfg):
    if not _exists(cfg, "explain_test_full.pkl"):
        return
    rows = load(out_dir(cfg) / "explain_test_full.pkl")
    out = [{"obj_id": r["obj_id"], "condition": r["condition"], "class": r["y_ref"], "alternative": r["y_alt"],
            "concept": r["k"], "raw_removal_amax": r["raw"][-1], "mean_control_amax": r["ctrl"][-1],
            "AIE": r["aie"], "CI": f"[{r['ci_lo']:.3f}, {r['ci_hi']:.3f}]", "G_minus": r["G_minus"],
            "role": r["role"], "audit_role": r["audit_role"]} for r in rows]
    _write(out, "table5_all_pairs", cfg)


# ------------------------------------------------------------------ Table VI
def table6(cfg, rows=None, name="table6_roles", write=True):
    rows = rows if rows is not None else load(out_dir(cfg) / "explain_test_full.pkl")
    rows = [r for r in rows if r["audit_role"] in ROLES]
    pred = np.array([r["role"] for r in rows])
    aud = np.array([r["audit_role"] for r in rows])
    per, macro, cov = role_report(pred, aud)
    if not write:
        return macro
    imgs = np.array([r["image_id"] for r in rows])
    rng = stream("stats", "table6")
    out = []
    for role in ROLES:
        ci = _f1_ci(imgs, pred, aud, role, cfg.stats.n_boot, rng)
        out.append({"role": role, "n": per[role]["n"], "precision": per[role]["P"], "recall": per[role]["R"],
                    "F1": per[role]["F1"], "F1_CI": f"[{ci[0]:.2f}, {ci[1]:.2f}]"})
    out.append({"role": "macro", "n": len(rows), "precision": macro["P"], "recall": macro["R"], "F1": macro["F1"],
                "F1_CI": ""})
    out.append({"role": "undetermined (withheld)", "n": cov["withheld"], "precision": np.nan, "recall": np.nan,
                "F1": np.nan, "F1_CI": f"assignment coverage {cov['coverage']:.3f}"})
    _write(out, name, cfg)
    return macro


def _f1_ci(imgs, pred, aud, role, n_boot, rng):
    ids = np.unique(imgs)
    groups = {i: np.where(imgs == i)[0] for i in ids}
    vals = []
    for _ in range(n_boot):
        s = np.concatenate([groups[i] for i in rng.choice(ids, len(ids))])
        p, a = pred[s], aud[s]
        tp = np.sum((p == role) & (a == role))
        P, R = tp / max(np.sum(p == role), 1), tp / max(np.sum(a == role), 1)
        vals.append(2 * P * R / (P + R) if P + R else 0.0)
    return np.quantile(vals, [0.025, 0.975])


# ------------------------------------------------------------------ Table VII
def table7(cfg):
    if not _exists(cfg, "adverse_triplets.pkl"):
        return
    res = load(out_dir(cfg) / "adverse_triplets.pkl")
    out = []
    for cond, recs in res.items():
        v = [r for r in recs if r["valid"]]
        M, L = np.array([r["M"] for r in v]), np.array([r["L"] for r in v])
        rm = np.array([r["rec_M"] for r in v]); rl = np.array([r["rec_L"] for r in v])
        out.append({"condition": cond, "valid_triplets": len(v),
                    "margin_c/a/r": "/".join(f"{x:.2f}" for x in M.mean(0)) if len(v) else "",
                    "margin_recovery_pct": 100 * float(np.nanmean(rm)) if np.isfinite(rm).any() else np.nan,
                    "iou_c/a/r": "/".join(f"{x:.2f}" for x in L.mean(0)) if len(v) else "",
                    "loc_recovery_pct": 100 * float(np.nanmean(rl)) if np.isfinite(rl).any() else np.nan,
                    "unmatched": len(recs) - len(v),
                    "missing_role_rate_pct": 100 * float(np.mean([r["missing_any"] for r in v])) if v else np.nan})
    _write(out, "table7_adverse", cfg)


# ------------------------------------------------------------------ Table VIII
def table8(cfg, write=True):
    if not _exists(cfg, "failure_cases.pkl"):
        return None
    f = load(out_dir(cfg) / "failure_cases.pkl")
    sc = MechanismScaler().fit(np.array([r["gamma_main"] for r in f["dev"]]))
    test = f["test"]
    pred = sc.predict(np.array([r["gamma_main"] for r in test]))
    gold = sc.predict(np.array([r["gamma_audit"] for r in test]))
    per, macro = multilabel_report(pred, gold, MECHANISMS)
    if not write:
        return macro
    out, cons = [], []
    for j, m in enumerate(MECHANISMS):
        rec = np.array([r["rec_L"] if m == "localization" else r["rec_M"] for r in test])
        elig = pred[:, j] & gold[:, j] & np.isfinite(rec)
        n_rec = int(np.sum(rec[elig] >= 0.5))
        c = n_rec / max(elig.sum(), 1)
        cons.append(c)
        out.append({"mechanism": m, "positive_labels": per[m]["n"], "precision": per[m]["P"], "recall": per[m]["R"],
                    "F1": per[m]["F1"], "cohort": len(test),
                    "recovery_consistency": f"{100 * c:.1f}% ({n_rec}/{int(elig.sum())})"})
    out.append({"mechanism": "macro", "positive_labels": int(gold.sum()), "precision": macro["P"],
                "recall": macro["R"], "F1": macro["F1"], "cohort": len(test),
                "recovery_consistency": f"{100 * np.mean(cons):.1f}% (mean)"})
    _write(out, "table8_failure", cfg)
    return macro


# ------------------------------------------------------------------ Table IX
def _phi(rows, ablation="full"):
    from .calibration import features
    X = features([abs(r["aie"]) for r in rows], [r["ci_hi"] - r["ci_lo"] for r in rows],
                 [r["G_minus"] for r in rows], [r["var_rep"] for r in rows], [r["valid"] for r in rows],
                 [r["rec_M"] for r in rows], [r["rec_L"] for r in rows],
                 [np.isfinite(r["rec_M"]) or np.isfinite(r["rec_L"]) for r in rows])
    if ablation == "no_localization":
        X[:, 6] = 0.0
    if ablation == "no_adverse":
        X[:, 5:] = 0.0
    return X


def _yrel(rows):
    return np.array([float(r["role"] == r["audit_role"] and r["audit_valid"]) for r in rows])


def table9(cfg, ablation="full", write=True):
    names = [f"explain_{s}_{ablation}.pkl" for s in ("dev", "cal", "test")]
    if not all(_exists(cfg, n) for n in names):
        return None
    dev, calr, test = [load(out_dir(cfg) / n) for n in names]
    assigned = lambda rs: [r for r in rs if r["role"] != UNDETERMINED]
    dev, calr, test_a = assigned(dev), assigned(calr), assigned(test)
    C = cal.ReliabilityCalibrator(cfg.calibration.lambda_w).fit_score(_phi(dev, ablation), _yrel(dev))
    C.fit_platt(_phi(calr, ablation), _yrel(calr))
    Xt, yt = _phi(test_a, ablation), _yrel(test_a)
    p0 = C.predict_uncalibrated(Xt)
    p1 = p0 if ablation == "no_calibration" else C.predict(Xt)
    qc = C.predict(_phi(calr, ablation)) if ablation != "no_calibration" else C.predict_uncalibrated(_phi(calr, ablation))
    tL, tH = cfg.calibration.tau_L, cfg.calibration.tau_H
    if tL is None or tH is None:
        tL, tH = cal.select_thresholds(_yrel(calr), qc, cfg.calibration.target_risk_report,
                                       cfg.calibration.target_risk_uncertain)
    m = {"ece": (cal.ece(yt, p0, cfg.calibration.ece_bins), cal.ece(yt, p1, cfg.calibration.ece_bins)),
         "brier": (cal.brier(yt, p0), cal.brier(yt, p1)), "auroc": (cal.auroc(yt, p0), cal.auroc(yt, p1)),
         "nll": (cal.nll(yt, p0), cal.nll(yt, p1))}
    risk75 = cal.risk_at_coverage(yt, p1, 0.75)[0] if ablation != "no_abstention" else np.nan
    if not write:
        return {"ece": m["ece"][1], "risk75": risk75}
    n_all = len(test)
    out = [{"family": "calibration", "metric": k.upper(), "before": v[0], "after": v[1], "coverage": "---"}
           for k, v in m.items()]
    for c in cfg.calibration.coverages:
        r0, n = cal.risk_at_coverage(yt, p0, c)
        r1, _ = cal.risk_at_coverage(yt, p1, c)
        out.append({"family": "selective risk", "metric": f"risk@{int(c * 100)}% conditional", "before": r0,
                    "after": r1, "coverage": f"{n}/{len(yt)} conditional; {n}/{n_all} overall ({100 * n / n_all:.1f}%)"})
    zs = cal.zone_summary(yt, p1, tL, tH, n_all)
    for z, v in zs.items():
        out.append({"family": "tri-zone", "metric": z, "before": np.nan, "after": v["risk"],
                    "coverage": f"{v['n']}/{len(yt)} conditional; {v['n']}/{n_all} overall ({100 * v['overall_cov']:.1f}%)"})
    out.append({"family": "thresholds", "metric": "tau_L / tau_H", "before": np.nan, "after": np.nan,
                "coverage": f"{tL:.2f} / {tH:.2f} (selected on calibration split)"})
    _write(out, "table9_calibration", cfg)
    return {"ece": m["ece"][1], "risk75": risk75}


# ------------------------------------------------------------------ Table X
def table10(cfg):
    full = out_dir(cfg) / "explain_test_full.pkl"
    if not full.exists():
        return
    full_rows = load(full)
    keyf = lambda r: (r["obj_id"], r["condition"], r["k"])
    fk, fdir = _dir_set(full_rows)
    out = []
    ref_correct = None
    for ab in cfg.ablations:
        p = out_dir(cfg) / f"explain_test_{ab}.pkl"
        if not p.exists():
            log(f"skip ablation {ab}: run `explain --ablation {ab}` on dev/cal/test")
            continue
        rows = {keyf(r): r for r in load(p)}
        pairs = [(rows[keyf(r)], a) for r, a in zip(fk, fdir) if keyf(r) in rows]
        sc = np.array([r["aie"] for r, _ in pairs])
        cf, corr = contrastive_fidelity(sc, cfg.roles.delta_M, np.array([a for _, a in pairs]))
        ba, _, _ = box_agreement(sc, cfg.roles.delta_M, np.array([r["audit_iou_loss"] for r, _ in pairs]),
                                 cfg.roles.delta_L)
        macro = table6(cfg, list(rows.values()), write=False)
        c9 = table9(cfg, ab, write=False) or {"ece": np.nan, "risk75": np.nan}
        fm = table8(cfg, write=False) if ab == "full" else None
        imgs = np.array([r["image_id"] for r, _ in pairs])
        if ab == "full":
            ref_correct = dict(zip([keyf(r) for r, _ in pairs], corr))
            delta = "reference"
        else:
            ks = [keyf(r) for r, _ in pairs]
            rc = np.array([ref_correct.get(k, np.nan) for k in ks])
            ok = np.isfinite(rc)
            d = cluster_bootstrap_diff(imgs[ok], rc[ok], corr[ok], cfg.stats.n_boot, stream("stats", "table10", ab))
            delta = f"{d[0]:+.3f} [{d[1][0]:.3f}, {d[1][1]:.3f}]"
        out.append({"configuration": ab, "CF": cf, "role_macro_F1": macro["F1"],
                    "failure_macro_F1": (fm or {}).get("F1", np.nan) if ab != "no_adverse" else np.nan,
                    "box_agreement": ba, "role_ECE": c9["ece"], "risk@75": c9["risk75"], "paired_delta_CF": delta})
    _write(out, "table10_ablation", cfg)


# ------------------------------------------------------------------ Table XI and Fig. 4
def table11(cfg):
    if _exists(cfg, "cross_detector.pkl"):
        _write(load(out_dir(cfg) / "cross_detector.pkl"), "table11_cross_detector", cfg)


def fig4(cfg):
    if _exists(cfg, "robustness.pkl"):
        _write(load(out_dir(cfg) / "robustness.pkl"), "fig4_robustness_ap", cfg)


def evaluate_all(cfg):
    fig4(cfg); table4(cfg); table5(cfg)
    if (out_dir(cfg) / "explain_test_full.pkl").exists():
        table6(cfg)
    table7(cfg); table8(cfg); table9(cfg); table10(cfg); table11(cfg)
