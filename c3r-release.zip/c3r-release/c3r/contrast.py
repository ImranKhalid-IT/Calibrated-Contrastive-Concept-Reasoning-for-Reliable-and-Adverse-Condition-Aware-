"""Fixed plausible alternative class (Eq. 9) and contrastive log-margin (Eq. 10)."""
from __future__ import annotations

import numpy as np


def confusion_from_dev(true_labels, pred_labels, classes) -> dict:
    """P_dev(Y = c | Yhat = y) estimated on clean development objects."""
    true_labels, pred_labels = np.asarray(true_labels), np.asarray(pred_labels)
    conf = {}
    for y in classes:
        sel = pred_labels == y
        conf[int(y)] = {int(c): float(np.mean(true_labels[sel] == c)) if sel.any() else 0.0 for c in classes}
    return conf


def select_alternative(y_ref: int, probs: dict, classes, supercat: dict, confusion: dict,
                       top_L: int = 5, w=(0.4, 0.3, 0.3), top2_only: bool = False) -> int:
    """Eq. 9: y^- = argmax_{c in T_g^-} w_p u(c) + w_s v(c) + w_c w(c).

    probs: {class: clean conditional probability} for the matched candidate.
    supercat: {class: COCO supercategory}; semantic proximity v(c) = 1 if same supercategory.
    The candidate set T_g^- is the top-L classes by development confusion and clean probability.
    `top2_only` implements the "top-2 competitor only" ablation (highest non-reference score).
    """
    cands = [c for c in classes if c != y_ref]
    if top2_only:
        return int(max(cands, key=lambda c: probs.get(c, 0.0)))
    logp = {c: np.log(probs.get(c, 0.0) + 1e-8) for c in cands}
    lo, hi = min(logp.values()), max(logp.values())
    u = {c: (logp[c] - lo) / (hi - lo + 1e-12) for c in cands}
    conf = confusion.get(int(y_ref), {})
    pre = sorted(cands, key=lambda c: (conf.get(c, 0.0), probs.get(c, 0.0)), reverse=True)[:top_L]
    score = {c: w[0] * u[c] + w[1] * float(supercat.get(c) == supercat.get(y_ref)) + w[2] * conf.get(c, 0.0)
             for c in pre}
    return int(max(score, key=score.get))


def log_margin(p_ref: float, p_alt: float, eps: float = 1e-6) -> float:
    """Eq. 10: M = log(p(y*) + eps) - log(p(y^-) + eps)."""
    return float(np.log(p_ref + eps) - np.log(p_alt + eps))
