"""Object-level C3R explainer: combines matching, concept coding, controlled interventions,
image-level validation, missing-evidence verification and role assignment for one detector.

`stream_tag` selects the seed stream: "main" for role assignment / calibrator features and
"audit" for the independent procedural audit (Eqs. 28-29). The two never share seeds.
"""
from __future__ import annotations

import numpy as np

from .contrast import select_alternative
from .detectors.base import CLASS_INDEX
from .image_edits import concept_maps, image_insertion, image_removal
from .interventions import (cross_level_agreement, insertion_gain, missing_decision, missing_deficit,
                            removal_intervention, sgn_dead)
from .matching import match_objects
from .roles import assign_role, chi_spurious
from .seeding import stream


class Explainer:
    def __init__(self, det, cs, priors, confusion, supercat, env_set, exemplars, cfg, ablation="full"):
        self.det, self.cs, self.cfg, self.ab = det, cs, cfg, ablation
        self.pi, self.mu = priors
        self.confusion, self.supercat = confusion, supercat
        self.env = set(int(k) for k in env_set)
        self.ex = exemplars
        self.K = cfg.concepts.K

    # -------------------------------------------------------------- per-image matching
    def match(self, img, gt_boxes):
        dets = self.det.detect(img)
        assign, valid, ious = match_objects(gt_boxes, dets.boxes, self.cfg.matching.kappa)
        return dets, assign, valid, ious

    def context(self, img, dets, cand, gt_box, gt_cls, y_alt=None, a_clean=None, obj_id=None, condition="clean"):
        """Everything needed to explain one matched object (g) under one condition."""
        self.det.prepare(img)
        h = dets.handles[cand]
        iface = dets.iface[cand]
        z = np.asarray(dets.feats[cand], float)
        a = self.cs.code(iface, z, self.cfg.concepts.lambda_1, self.cfg.concepts.ista_iters)[0]
        probs = dets.probs[cand]
        classes = list(CLASS_INDEX)
        if y_alt is None:
            pdict = {c: float(probs[CLASS_INDEX[c]]) for c in classes}
            w = self.cfg.contrast.weights
            y_alt = select_alternative(int(gt_cls), pdict, classes, self.supercat, self.confusion,
                                       self.cfg.contrast.top_L, (w.prob, w.semantic, w.confusion),
                                       top2_only=self.ab == "top2_competitor")
        code_fn = lambda Z: self.cs.code(iface, Z, self.cfg.concepts.lambda_1, self.cfg.concepts.ista_iters)
        maps, _ = concept_maps(self.det, img, h, code_fn, dets.boxes[cand], self.cfg.intervention.occlusion_grid)
        return dict(img=img, handle=h, iface=iface, z=z, a=a, BD=self.cs.BD(iface), gt_box=np.asarray(gt_box, float),
                    det_box=dets.boxes[cand], y_ref=int(gt_cls), y_alt=int(y_alt),
                    y_idx=CLASS_INDEX[int(gt_cls)], alt_idx=CLASS_INDEX[int(y_alt)],
                    maps=maps, a_clean=a_clean, obj_id=obj_id, condition=condition,
                    d_img=float(np.hypot(*img.shape[:2])))

    # -------------------------------------------------------------- per concept
    def explain_pair(self, c: dict, k: int, stream_tag="main", with_image=True) -> dict:
        cfg, ab = self.cfg, self.ab
        rng = stream(stream_tag, c["obj_id"], c["condition"], k)
        head = self.det.head_fn(c["handle"])
        iv = cfg.intervention
        res = removal_intervention(c["z"], c["a"], k, c["BD"], head, c["y_idx"], c["alt_idx"], iv.doses,
                                   iv.n_controls, rng, c["gt_box"], c["d_img"], iv.epsilon,
                                   cfg.roles.ci_level, cfg.roles.n_boot, use_controls=ab != "no_controls")
        # image-level removal and feature-image agreement G^- (Eq. 15)
        if with_image and ab != "no_image_validation":
            img_reps, valid_rm, _ = image_removal(
                self.det, c["img"], c["handle"], c["det_box"], c["maps"][k], iv.mask_quantile, iv.doses,
                c["y_idx"], c["alt_idx"], rng, iv.n_replicates, iv.n_controls, cfg.matching.kappa, iv.max_regions)
            groups = np.array_split(np.arange(res.ctrl_draws.shape[1]), iv.n_replicates)
            from .interventions import integrate_dose
            feat_reps = [integrate_dose(res.doses, res.raw - res.ctrl_draws[:, g].mean(1)) for g in groups]
            G_minus = cross_level_agreement(feat_reps, img_reps, cfg.roles.delta_M)
        else:
            G_minus, valid_rm = 1.0, 1.0
        # missing evidence (Eqs. 16-19)
        y = c["y_ref"]
        pi_yk = self.pi.get(y, np.zeros(self.K))[k]
        mu_yk = self.mu.get(y, np.zeros(self.K))[k]
        d = missing_deficit(c["a"][k], pi_yk, mu_yk, cfg.missing.pi_0)
        U, G_plus, miss = 0.0, 0.0, False
        if ab != "no_missing" and d > cfg.missing.delta_a:
            U = insertion_gain(c["z"], c["a"], k, d, c["BD"], head, c["y_idx"], c["alt_idx"],
                               cfg.missing.beta_in, cfg.missing.d_max, iv.epsilon)
            if with_image and ab != "no_image_validation":
                ex = self.ex.get((y, k), self.ex.get((-1, k)))
                gains, _ = image_insertion(self.det, c["img"], c["handle"], c["det_box"], ex, 0.8,
                                           c["y_idx"], c["alt_idx"], rng, iv.n_replicates, cfg.matching.kappa)
                G_plus = float(np.mean(sgn_dead(gains, cfg.roles.delta_M) == sgn_dead(U, cfg.roles.delta_M)))
            else:
                G_plus = 1.0
            miss = missing_decision(d, U, G_plus, cfg.missing.delta_a, cfg.roles.delta_M, cfg.roles.g_0)
        # environmental evidence (only defined for adverse inputs with a clean reference)
        chi = 0.0
        if c["a_clean"] is not None and k in self.env:
            chi = chi_spurious(c["a"][k], c["a_clean"][k], res.aie)
        role = assign_role(res.ci, G_minus, miss, k in self.env, chi, cfg.roles.delta_M,
                           cfg.roles.delta_eq, cfg.roles.g_0, cfg.roles.gamma_env)
        return dict(k=k, aie=res.aie, ci_lo=res.ci[0], ci_hi=res.ci[1], raw=res.raw.tolist(),
                    ctrl=res.ctrl_mean.tolist(), G_minus=G_minus, G_plus=G_plus, var_rep=res.var_rep,
                    valid=float(valid_rm >= 0.5), d=d, U_plus=U, miss=miss, chi=chi, role=role,
                    obj_change=res.obj_change, iou_loss=res.iou_loss, displacement=res.displacement,
                    box_var=res.box_var, a_k=float(c["a"][k]))
