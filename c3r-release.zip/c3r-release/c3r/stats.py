"""Statistical inference: image-clustered paired bootstrap (Eq. 35) and Holm correction."""
from __future__ import annotations

import numpy as np


def cluster_bootstrap_diff(image_ids, correct_a, correct_b, n_boot: int, rng, level: float = 0.95):
    """Paired image-clustered bootstrap of the difference in mean per-pair accuracy.

    image_ids: (N,) cluster id per object-concept pair; correct_a/b: (N,) 0/1 per pair for the
    two methods evaluated on the same pairs. Returns (delta_hat, (lo, hi), p_two_sided).
    """
    image_ids = np.asarray(image_ids)
    a, b = np.asarray(correct_a, float), np.asarray(correct_b, float)
    ids, inv = np.unique(image_ids, return_inverse=True)
    sa, sb = np.bincount(inv, a), np.bincount(inv, b)
    cnt = np.bincount(inv)
    delta = (sa.sum() - sb.sum()) / cnt.sum()
    boots = np.empty(n_boot)
    for i in range(n_boot):
        s = rng.integers(0, len(ids), len(ids))
        boots[i] = (sa[s].sum() - sb[s].sum()) / cnt[s].sum()
    lo, hi = np.quantile(boots, [(1 - level) / 2, 1 - (1 - level) / 2])
    p = 2 * min(np.mean(boots <= 0), np.mean(boots >= 0))
    return float(delta), (float(lo), float(hi)), float(min(1.0, p))


def cluster_bootstrap_ci(image_ids, values, n_boot, rng, stat=np.mean, level=0.95):
    image_ids, values = np.asarray(image_ids), np.asarray(values)
    ids = np.unique(image_ids)
    groups = {i: np.where(image_ids == i)[0] for i in ids}
    boots = []
    for _ in range(n_boot):
        s = rng.choice(ids, len(ids), replace=True)
        idx = np.concatenate([groups[i] for i in s])
        boots.append(stat(values[idx]))
    return tuple(np.quantile(boots, [(1 - level) / 2, 1 - (1 - level) / 2]).tolist())


def holm(pvals) -> np.ndarray:
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    adj = np.empty_like(p)
    running = 0.0
    for r, i in enumerate(order):
        running = max(running, (len(p) - r) * p[i])
        adj[i] = min(1.0, running)
    return adj
