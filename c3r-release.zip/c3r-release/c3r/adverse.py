"""Adverse-condition recovery (Eqs. 22-24) and the five failure mechanisms (Eq. 25).

The component formulas below implement the definitions stated in the manuscript text
(Section III-E) and Supplementary Section S8.
"""
from __future__ import annotations

import numpy as np

MECHANISMS = ["spurious", "suppression", "localization", "context", "instability"]


def recovery(v_clean, v_adv, v_rest, eps):
    """Eqs. 23-24: (v^r - v^a) / (v^c - v^a), defined only when v^c - v^a > eps.
    Values outside [0, 1] are kept (failure / overshoot). Returns nan when undefined."""
    d = v_clean - v_adv
    return float((v_rest - v_adv) / d) if d > eps else float("nan")


def env_shift(aie_adv, aie_clean):
    """Eq. 22."""
    return np.asarray(aie_adv) - np.asarray(aie_clean)


def failure_vector(o: dict) -> np.ndarray:
    """Raw (unscaled) mechanism evidence Gamma_g (Eq. 25).

    Required keys (all per object g, concepts split into environmental `env` and object `obj`):
      a_c, a_a           : (K,) concept activations, clean / adverse
      logp_alt_a, logp_alt_r : log p(y^-) adverse / restored
      U_plus_a           : (K,) insertion gains on the adverse input
      L_c, L_a, L_r      : ground-truth IoU per condition
      aie_c, aie_a       : (K,) controlled effects per condition
      var_c, var_a       : (K,) repeated-edit variances per condition
      env, obj           : index arrays of environmental / object concepts
    """
    env, obj = o["env"], o["obj"]
    relu = lambda x: np.maximum(x, 0.0)
    spur = relu(o["a_a"][env] - o["a_c"][env]).sum() * relu(o["logp_alt_a"] - o["logp_alt_r"])
    sup = (relu(o["a_c"][obj] - o["a_a"][obj]) * relu(o["U_plus_a"][obj])).sum()
    rec_L = recovery(o["L_c"], o["L_a"], o["L_r"], 0.0)
    loc = relu(o["L_c"] - o["L_a"]) * (np.clip(rec_L, 0, 1) if np.isfinite(rec_L) else 0.0)
    bg_rise = relu(np.abs(o["aie_a"][env]).sum() - np.abs(o["aie_c"][env]).sum())
    obj_fall = relu(o["aie_c"][obj].clip(min=0).sum() - o["aie_a"][obj].clip(min=0).sum())
    ctx = bg_rise * obj_fall
    unst = relu(o["var_a"].mean() - o["var_c"].mean())
    return np.array([spur, sup, loc, ctx, unst], float)


class MechanismScaler:
    """Independent per-component rescaling (fixed on development data) and thresholds."""

    def __init__(self, q: float = 0.95):
        self.q = q
        self.scale = None
        self.theta = None

    def fit(self, G_dev: np.ndarray, Y_dev: np.ndarray | None = None):
        G_dev = np.asarray(G_dev, float)
        self.scale = np.maximum(np.quantile(G_dev, self.q, axis=0), 1e-12)
        Gs = self.transform(G_dev)
        if Y_dev is None:
            self.theta = np.full(G_dev.shape[1], 0.5)
        else:  # F1-maximising threshold per mechanism on development cases
            self.theta = np.array([self._best_thr(Gs[:, j], Y_dev[:, j]) for j in range(Gs.shape[1])])
        return self

    @staticmethod
    def _best_thr(s, y):
        best, bt = -1, 0.5
        for t in np.unique(np.round(s, 3)):
            p = s >= t
            tp = np.sum(p & y)
            f = 2 * tp / max(p.sum() + y.sum(), 1)
            if f > best:
                best, bt = f, t
        return bt

    def transform(self, G):
        return np.minimum(np.asarray(G, float) / self.scale, 1.0)

    def predict(self, G):
        return self.transform(G) >= self.theta
