"""Deterministic seed streams derived from a single base seed (Table III).

Every random quantity in C3R draws from a *named* stream, e.g. ``stream("control", g, k)``.
Streams are reproducible and independent; the audit streams use the prefix ``audit`` and are
never used for role assignment or calibrator features, so that
S_audit ∩ (S_role ∪ S_feat) = ∅ (Eq. 29).
"""
from __future__ import annotations

import random
import zlib

import numpy as np

_BASE_SEED = 42


def set_base_seed(seed: int) -> None:
    global _BASE_SEED
    _BASE_SEED = int(seed)
    random.seed(seed)
    np.random.seed(seed % (2**32))
    try:
        import torch

        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except ImportError:
        pass


def _key(parts) -> list[int]:
    out = []
    for p in parts:
        if isinstance(p, (int, np.integer)):
            out.append(int(p) & 0xFFFFFFFF)
        else:
            out.append(zlib.crc32(str(p).encode("utf-8")))
    return out


def stream(*parts) -> np.random.Generator:
    """Return an independent generator for the given named stream."""
    return np.random.default_rng(np.random.SeedSequence([_BASE_SEED, *_key(parts)]))


def stream_seed(*parts) -> int:
    return int(stream(*parts).integers(0, 2**31 - 1))
