"""Controlled, dose-integrated concept interventions (Eqs. 11-15, 16-20).

All functions are detector-agnostic. A detector wrapper supplies a *head* callable

    head(Z: np.ndarray[B, d_z]) -> dict(probs=[B, C], obj=[B], box=[B, 4])

that re-evaluates the frozen detection head at the matched candidate (same proposal,
grid cell, or object query) for edited native features Z.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .matching import box_iou


def sgn_dead(x, delta: float):
    """Dead-zone sign (Eq. 32): +1 if x > delta, -1 if x < -delta, else 0."""
    x = np.asarray(x, dtype=float)
    return np.where(x > delta, 1, np.where(x < -delta, -1, 0))


def native_edit(z: np.ndarray, BD: np.ndarray, delta_a: np.ndarray) -> np.ndarray:
    """Eq. 12: z^I = z + B_m D (a^I - a), retaining the non-concept residual."""
    return z + BD @ delta_a


def nonsemantic_controls(delta_z: np.ndarray, BD: np.ndarray, n: int, rng: np.random.Generator) -> np.ndarray:
    """Matched-energy nonsemantic control edits for one dose.

    Random directions are projected onto the orthogonal complement of the decoded concept
    subspace span(B_m D) and rescaled to ||delta_z||, so they carry the same energy but no
    concept content. Returns (n, d_z).
    """
    Q, _ = np.linalg.qr(BD)
    R = rng.standard_normal((n, len(delta_z)))
    R = R - (R @ Q) @ Q.T
    R /= np.linalg.norm(R, axis=1, keepdims=True) + 1e-12
    return R * np.linalg.norm(delta_z)


def margin_from_out(out: dict, y_ref_idx: int, y_alt_idx: int, eps: float) -> np.ndarray:
    p = out["probs"]
    return np.log(p[:, y_ref_idx] + eps) - np.log(p[:, y_alt_idx] + eps)


@dataclass
class InterventionResult:
    doses: np.ndarray
    raw: np.ndarray                 # D^raw(alpha), Eq. 13
    ctrl_mean: np.ndarray           # mean control effect per dose
    controlled: np.ndarray          # D-tilde(alpha), Eq. 14
    aie: float                      # Eq. 15 (Eq. "aie")
    ci: tuple                       # Eq. 27
    var_rep: float                  # variance of AIE across control replicates
    obj_change: float               # o^0 - o^I at alpha_max
    iou_loss: float                 # IoU(b0,b*) - IoU(bI,b*) at alpha_max
    displacement: float             # ||bI - b0||_1 / d_img
    box_var: float                  # trace Cov_r(b^I)
    ctrl_draws: np.ndarray = field(repr=False, default=None)   # (n_doses, B)


def _trapz(y, x):
    y, x = np.asarray(y, float), np.asarray(x, float)
    return float(np.sum((y[1:] + y[:-1]) * np.diff(x)) / 2.0)


def integrate_dose(doses: np.ndarray, values: np.ndarray, w=None) -> float:
    """Eq. 15: normalised weighted integral over [0, alpha_max] with D(0) = 0 (trapezoid)."""
    a = np.concatenate([[0.0], doses])
    v = np.concatenate([[0.0], values])
    w = np.ones_like(a) if w is None else np.concatenate([[w[0]], w])
    return _trapz(w * v, a) / _trapz(w, a)


def removal_intervention(z, a, k, BD, head, y_idx, alt_idx, doses, n_controls, rng,
                         gt_box, d_img, eps=1e-6, ci_level=0.95, n_boot=1000,
                         use_controls=True) -> InterventionResult:
    """Graded suppression of concept k (Eqs. 11-15) with matched controls and paired CI."""
    doses = np.asarray(doses, float)
    base = head(z[None])
    M0 = margin_from_out(base, y_idx, alt_idx, eps)[0]
    raw, ctrl_all, edited_boxes = [], [], []
    for alpha in doses:
        da = np.zeros_like(a)
        da[k] = -alpha * a[k]                          # Eq. 11
        dz = BD @ da
        out = head(native_edit(z, BD, da)[None])
        raw.append(M0 - margin_from_out(out, y_idx, alt_idx, eps)[0])   # Eq. 13
        edited_boxes.append(out["box"][0])
        if use_controls and np.linalg.norm(dz) > 0:
            C = nonsemantic_controls(dz, BD, n_controls, rng)
            co = head(z[None] + C)
            ctrl_all.append(M0 - margin_from_out(co, y_idx, alt_idx, eps))
        else:
            ctrl_all.append(np.zeros(max(n_controls, 1)))
    raw = np.array(raw)
    ctrl_all = np.array(ctrl_all)                      # (n_doses, B)
    controlled = raw - ctrl_all.mean(1)                # Eq. 14
    aie = integrate_dose(doses, controlled)
    # paired resampling of control draws at the object level (Eq. 27)
    B = ctrl_all.shape[1]
    boots = np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, B, B)
        boots[b] = integrate_dose(doses, raw - ctrl_all[:, idx].mean(1))
    lo, hi = np.quantile(boots, [(1 - ci_level) / 2, 1 - (1 - ci_level) / 2])
    # replicate variance: split controls into 5 disjoint replicate groups
    groups = np.array_split(np.arange(B), min(5, B))
    rep = [integrate_dose(doses, raw - ctrl_all[:, g].mean(1)) for g in groups]
    last = head(native_edit(z, BD, -doses[-1] * a[k] * np.eye(len(a))[k])[None])
    b0, bI = base["box"][0], last["box"][0]
    return InterventionResult(
        doses=doses, raw=raw, ctrl_mean=ctrl_all.mean(1), controlled=controlled, aie=aie,
        ci=(float(lo), float(hi)), var_rep=float(np.var(rep)),
        obj_change=float(base["obj"][0] - last["obj"][0]),
        iou_loss=float(box_iou(b0[None], gt_box[None])[0, 0] - box_iou(bI[None], gt_box[None])[0, 0]),
        displacement=float(np.abs(bI - b0).sum() / d_img),
        box_var=float(np.trace(np.cov(np.array(edited_boxes).T))) if len(edited_boxes) > 1 else 0.0,
        ctrl_draws=ctrl_all,
    )


def missing_deficit(a_k: float, pi_yk: float, mu_yk: float, pi_0: float) -> float:
    """Eq. 16: d = 1{pi >= pi_0} ReLU(mu - a)."""
    return float(pi_yk >= pi_0) * max(0.0, mu_yk - a_k)


def insertion_gain(z, a, k, d, BD, head, y_idx, alt_idx, beta_in, d_max, eps=1e-6) -> float:
    """Eqs. 17-18: U+ = M(a + beta_in min(d, d_max) e_k) - M(a)."""
    da = np.zeros_like(a)
    da[k] = beta_in * min(d, d_max)
    M0 = margin_from_out(head(z[None]), y_idx, alt_idx, eps)[0]
    M1 = margin_from_out(head(native_edit(z, BD, da)[None]), y_idx, alt_idx, eps)[0]
    return float(M1 - M0)


def missing_decision(d, U_plus, G_plus, delta_a, delta_M, g_0) -> bool:
    """Eq. 19."""
    return bool(d > delta_a and U_plus > delta_M and G_plus >= g_0)


def cross_level_agreement(feat_effects, image_effects, delta: float) -> float:
    """Eq. 15 (G): sign concordance between feature- and image-level controlled effects."""
    f = sgn_dead(np.asarray(feat_effects), delta)
    i = sgn_dead(np.asarray(image_effects), delta)
    return float(np.mean(f == i)) if len(f) else 0.0
