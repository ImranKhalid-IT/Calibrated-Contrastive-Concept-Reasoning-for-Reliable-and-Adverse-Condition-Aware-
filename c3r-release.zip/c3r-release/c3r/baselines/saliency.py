"""Saliency baselines evaluated in contrastive form at the fixed matched candidate (Eq. 36).

Grad-CAM++ and Score-CAM use the FPN level of the matched RoI of the primary Faster R-CNN
detector; D-RISE is detector-agnostic (random masks evaluated at the same candidate).
All maps are returned in original image coordinates; S_g^E(u) = S(u; y*) - S(u; y^-).
"""
from __future__ import annotations

import cv2
import numpy as np
import torch
import torch.nn.functional as F

from ..matching import box_iou


def _act_to_image(cam: torch.Tensor, il, orig_hw):
    H, W = il.tensors.shape[-2:]
    up = F.interpolate(cam[None, None], size=(H, W), mode="bilinear", align_corners=False)[0, 0]
    h, w = il.image_sizes[0]
    up = up[:h, :w].detach().cpu().numpy()
    return cv2.resize(up, (orig_hw[1], orig_hw[0]), interpolation=cv2.INTER_LINEAR)


def gradcampp(det, img, handle, y_ref: int, y_alt: int):
    out = {}
    for name, cls in (("ref", y_ref), ("alt", y_alt)):
        logits, act, il = det.logits_and_activation(img, handle)
        score = logits[det.idx91(cls)]
        g = torch.autograd.grad(score, act)[0][0]          # (C,h,w)
        A = act[0].detach()
        g2, g3 = g ** 2, g ** 3
        denom = 2 * g2 + (A * g3).sum((1, 2), keepdim=True)
        alpha = g2 / torch.where(denom != 0, denom, torch.ones_like(denom))
        w = (alpha * F.relu(g)).sum((1, 2))
        cam = F.relu((w[:, None, None] * A).sum(0))
        out[name] = _act_to_image(cam, il, img.shape[:2])
    return out["ref"] - out["alt"]


def scorecam(det, img, handle, y_ref: int, y_alt: int, n_channels: int = 64, batch: int = 8):
    with torch.no_grad():
        _, act, il = det.logits_and_activation(img, handle)
    A = act[0].detach()
    top = torch.argsort(A.mean((1, 2)), descending=True)[:n_channels]
    maps, imgs = [], []
    for c in top:
        m = _act_to_image(A[c], il, img.shape[:2])
        m = (m - m.min()) / (m.max() - m.min() + 1e-8)
        maps.append(m)
        imgs.append((img.astype(np.float32) * m[..., None]).astype(np.uint8))
    _, out = det.features_at(imgs, handle, batch=batch)
    _, base = det.features_at([np.zeros_like(img)], handle)
    i_ref, i_alt = det.idx80(y_ref), det.idx80(y_alt)
    sal = {}
    for name, i in (("ref", i_ref), ("alt", i_alt)):
        w = torch.softmax(torch.tensor(out["probs"][:, i] - base["probs"][0, i]), 0).numpy()
        sal[name] = np.maximum((w[:, None, None] * np.stack(maps)).sum(0), 0)
    return sal["ref"] - sal["alt"]


def drise(det, img, handle, y_ref_idx80: int, y_alt_idx80: int, target_box, rng,
          n_masks=1000, grid=16, p=0.5, batch=8):
    H, W = img.shape[:2]
    cell_h, cell_w = int(np.ceil(H / grid)), int(np.ceil(W / grid))
    sal_ref, sal_alt = np.zeros((H, W), np.float32), np.zeros((H, W), np.float32)
    for s in range(0, n_masks, batch):
        ms, ims = [], []
        for _ in range(min(batch, n_masks - s)):
            g = (rng.random((grid, grid)) < p).astype(np.float32)
            up = cv2.resize(g, ((grid + 1) * cell_w, (grid + 1) * cell_h), interpolation=cv2.INTER_LINEAR)
            dy, dx = rng.integers(0, cell_h), rng.integers(0, cell_w)
            m = up[dy:dy + H, dx:dx + W]
            ms.append(m)
            ims.append((img.astype(np.float32) * m[..., None]).astype(np.uint8))
        _, out = det.features_at(ims, handle)
        iou = box_iou(out["box"], np.asarray(target_box)[None])[:, 0]
        for m, pr, io, ob in zip(ms, out["probs"], iou, out["obj"]):
            sal_ref += m * (io * ob * pr[y_ref_idx80])
            sal_alt += m * (io * ob * pr[y_alt_idx80])
    return (sal_ref - sal_alt) / n_masks
