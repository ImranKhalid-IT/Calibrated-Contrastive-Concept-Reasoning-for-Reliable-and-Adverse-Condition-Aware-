"""Deletion / insertion AUC (Eq. 43) at the fixed matched candidate, ranking pixels inside the
matched box. Deleted pixels are replaced by a blurred copy; insertion starts from the blurred
image and restores the top-ranked pixels."""
from __future__ import annotations

import cv2
import numpy as np

from ..metrics import curve_auc


def c3r_ranking_map(maps: np.ndarray, aie: np.ndarray) -> np.ndarray:
    """Eq. 44: S^{C3R}(u) = sum_k max(AIE_k, 0) * A_k(u) over the box crop."""
    return np.tensordot(np.maximum(aie, 0), maps, axes=1)


def deletion_insertion(det, img, handle, box, rank_map_box, y_idx, steps=10, batch=11):
    x1, y1, x2, y2 = [int(round(v)) for v in box]
    x1, y1 = max(x1, 0), max(y1, 0)
    x2, y2 = min(x2, img.shape[1]), min(y2, img.shape[0])
    h, w = y2 - y1, x2 - x1
    rm = cv2.resize(rank_map_box.astype(np.float32), (w, h))
    order = np.argsort(-rm.ravel(), kind="stable")
    blur = cv2.GaussianBlur(img, (0, 0), 12)
    dels, inss = [], []
    for f in np.linspace(0, 1, steps + 1):
        n = int(round(f * order.size))
        m = np.zeros(order.size, bool)
        m[order[:n]] = True
        m = m.reshape(h, w)
        d = img.copy(); d[y1:y2, x1:x2][m] = blur[y1:y2, x1:x2][m]
        i = blur.copy(); i[y1:y2, x1:x2][m] = img[y1:y2, x1:x2][m]
        dels.append(d); inss.append(i)
    _, od = det.features_at(dels, handle, batch=batch)
    _, oi = det.features_at(inss, handle, batch=batch)
    return curve_auc(od["probs"][:, y_idx]), curve_auc(oi["probs"][:, y_idx])
