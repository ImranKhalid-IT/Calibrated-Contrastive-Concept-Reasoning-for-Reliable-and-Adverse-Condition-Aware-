"""Object-level CRAFT adaptation (Eqs. 38-40).

CRAFT factorises native features z ~ sum_j u_j w_j with its own nonnegative dictionary (NMF).
Its concepts are aligned to the C3R dictionary by Hungarian matching of activation vectors on
development objects; only matches with cosine >= c_min are scored. The CRAFT concept effect is a
single full removal without matched controls or dose integration (Eq. 40).
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import linear_sum_assignment
from sklearn.decomposition import NMF

from ..interventions import margin_from_out


class CraftBaseline:
    def __init__(self, K: int, seed: int = 0):
        self.nmf = NMF(n_components=K, init="nndsvda", max_iter=500, random_state=seed)
        self.perm = None
        self.keep = None

    def fit(self, Z_dev: np.ndarray, A_c3r_dev: np.ndarray, c_min: float):
        Zp = np.clip(Z_dev, 0, None)
        U = self.nmf.fit_transform(Zp)
        self.W = self.nmf.components_                  # (K, d)
        Un = U / (np.linalg.norm(U, axis=0, keepdims=True) + 1e-12)
        An = A_c3r_dev / (np.linalg.norm(A_c3r_dev, axis=0, keepdims=True) + 1e-12)
        C = An.T @ Un                                   # cos(a_k, u_j)
        rows, cols = linear_sum_assignment(-C)
        self.perm = dict(zip(rows, cols))
        self.keep = {k for k, j in self.perm.items() if C[k, j] >= c_min}
        return self

    def concept_effect(self, z, head, y_idx, alt_idx, k, eps=1e-6):
        if k not in self.keep:
            return np.nan
        j = self.perm[k]
        u = self.nmf.transform(np.clip(z, 0, None)[None])[0]
        M0 = margin_from_out(head(z[None]), y_idx, alt_idx, eps)[0]
        M1 = margin_from_out(head((z - u[j] * self.W[j])[None]), y_idx, alt_idx, eps)[0]
        return float(M0 - M1)
