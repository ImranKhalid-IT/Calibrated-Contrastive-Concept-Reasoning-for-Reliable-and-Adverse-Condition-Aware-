"""Nonnegative sparse coding against a nonnegative dictionary (Eq. 5).

a* = argmin_{a >= 0} 0.5 ||h - D a||^2 + lambda_1 ||a||_1,  D >= 0,  ||D[:, k]||_2 <= 1.

Solved with projected FISTA. Works on numpy arrays; a torch version lives in alignment.py.
"""
from __future__ import annotations

import numpy as np


def project_dictionary(D: np.ndarray) -> np.ndarray:
    D = np.clip(D, 0.0, None)
    norms = np.linalg.norm(D, axis=0, keepdims=True)
    return D / np.maximum(norms, 1.0)


def sparse_code(H: np.ndarray, D: np.ndarray, lam: float, n_iter: int = 100) -> np.ndarray:
    """Codes for rows of H (N, d) with dictionary D (d, K). Returns A (N, K) >= 0."""
    H = np.atleast_2d(H).astype(np.float64)
    D = D.astype(np.float64)
    L = np.linalg.norm(D, 2) ** 2 + 1e-12
    DtD, DtH = D.T @ D, H @ D
    A = np.zeros((H.shape[0], D.shape[1]))
    Y, t = A.copy(), 1.0
    for _ in range(n_iter):
        grad = Y @ DtD - DtH
        A_new = np.maximum(Y - (grad + lam) / L, 0.0)
        t_new = 0.5 * (1 + np.sqrt(1 + 4 * t * t))
        Y = A_new + ((t - 1) / t_new) * (A_new - A)
        A, t = A_new, t_new
    return A


def objective(H, D, A, lam):
    return 0.5 * np.sum((H - A @ D.T) ** 2) + lam * np.abs(A).sum()
