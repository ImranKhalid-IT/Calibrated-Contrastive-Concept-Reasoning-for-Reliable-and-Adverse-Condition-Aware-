"""Clean class-conditional concept profiles (Eq. 8) and environmental-concept set."""
from __future__ import annotations

import numpy as np


def class_priors(A: np.ndarray, labels: np.ndarray, correct: np.ndarray, eta_a: float):
    """Prevalence pi[y,k] and mean activation mu[y,k] from correctly matched,
    correctly classified clean development objects only.

    A: (N,K) concept codes; labels: (N,) reference classes; correct: (N,) bool.
    Returns dicts {class_id: (K,) array}.
    """
    pi, mu = {}, {}
    for y in np.unique(labels[correct]):
        S = A[(labels == y) & correct]
        pi[int(y)] = (S > eta_a).mean(0)
        mu[int(y)] = S.mean(0)
    return pi, mu


def environmental_concepts(A_clean: np.ndarray, A_adv: np.ndarray, z_thresh: float = 0.5) -> np.ndarray:
    """Nuisance concepts K_env, fixed on development data before testing.

    A_clean / A_adv are codes of the *same* development objects on clean and corrupted inputs.
    A concept is environmental when the corruption raises its mean activation by more than
    z_thresh clean standard deviations (corruption-induced evidence).
    """
    shift = (A_adv - A_clean).mean(0)
    sd = A_clean.std(0) + 1e-8
    return np.where(shift / sd > z_thresh)[0]
