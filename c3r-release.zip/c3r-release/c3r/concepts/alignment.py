"""Cross-detector adapters, shared nonnegative dictionary and native decoders (Eqs. 3-7).

Training data: for each matched clean development object g, one native feature per detector
interface. Same-object features from different detectors are positives; other objects are
negatives (other views of the same object are excluded from the negative set).
"""
from __future__ import annotations

from collections import defaultdict

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def nonneg_embed(A: nn.Linear, z: torch.Tensor) -> torch.Tensor:
    """Eq. 3: h = Norm_2(softplus(A_m z)) with a zero-norm safeguard."""
    return F.normalize(F.softplus(A(z)), dim=-1, eps=1e-8)


def sparse_code_torch(H, D, lam, n_iter=100):
    """Projected FISTA for Eq. 5 (batched, no gradient)."""
    with torch.no_grad():
        L = torch.linalg.matrix_norm(D, 2) ** 2 + 1e-12
        DtD, DtH = D.T @ D, H @ D
        A = torch.zeros(H.shape[0], D.shape[1], device=H.device)
        Y, t = A.clone(), 1.0
        for _ in range(n_iter):
            A_new = torch.clamp(Y - (Y @ DtD - DtH + lam) / L, min=0)
            t_new = 0.5 * (1 + (1 + 4 * t * t) ** 0.5)
            Y = A_new + ((t - 1) / t_new) * (A_new - A)
            A, t = A_new, t_new
    return A


def info_nce(Hb: torch.Tensor, gid: torch.Tensor, tau: float) -> torch.Tensor:
    """Eq. 4. For every ordered positive pair (u, v) with gid[u] == gid[v], u != v, the
    denominator runs over v and all w with gid[w] != gid[u]."""
    S = Hb @ Hb.T / tau
    same = gid[:, None] == gid[None, :]
    eye = torch.eye(len(gid), dtype=torch.bool, device=Hb.device)
    pos = same & ~eye
    if not pos.any():
        return Hb.sum() * 0
    neg_mask = ~same
    neg_lse = torch.logsumexp(S.masked_fill(~neg_mask, float("-inf")), dim=1)   # over negatives
    u, v = torch.where(pos)
    s_pos = S[u, v]
    denom = torch.logaddexp(s_pos, neg_lse[u])
    return (denom - s_pos).mean()


class ConceptSpace(nn.Module):
    def __init__(self, dims: dict, embed_dim: int, K: int):
        super().__init__()
        self.ifaces = list(dims)
        self.A = nn.ModuleDict({self._k(m): nn.Linear(d, embed_dim) for m, d in dims.items()})
        self.B = nn.ParameterDict({self._k(m): nn.Parameter(torch.randn(d, embed_dim) * 0.01)
                                   for m, d in dims.items()})
        self.D = nn.Parameter(torch.rand(embed_dim, K))
        self.project()

    @staticmethod
    def _k(m):
        return m.replace("/", "__")

    def project(self):
        with torch.no_grad():
            self.D.clamp_(min=0)
            self.D.div_(self.D.norm(dim=0, keepdim=True).clamp(min=1.0))

    def embed(self, m, z):
        return nonneg_embed(self.A[self._k(m)], z)

    def BD(self, m) -> np.ndarray:
        """Decoded concept directions in native space, B_m D (d_z x K)."""
        return (self.B[self._k(m)] @ self.D).detach().cpu().numpy()

    def code(self, m, z: np.ndarray, lam: float, n_iter=100) -> np.ndarray:
        dev = self.D.device
        with torch.no_grad():
            h = self.embed(m, torch.as_tensor(np.atleast_2d(z), dtype=torch.float32, device=dev))
            return sparse_code_torch(h, self.D, lam, n_iter).cpu().numpy()


def train_concept_space(records: list, cfg, device="cuda", use_alignment=True, log=print) -> ConceptSpace:
    """records: list of dicts {gid, iface, z} from matched clean development objects.
    Optimises Eq. 7: L_align + lambda_h ||h - D a||^2 + lambda_z ||z - B_m D a||^2 + lambda_1 ||a||_1."""
    dev = torch.device(device if torch.cuda.is_available() else "cpu")
    dims = {}
    for r in records:
        dims.setdefault(r["iface"], len(r["z"]))
    model = ConceptSpace(dims, cfg.embed_dim, cfg.K).to(dev)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    by_g = defaultdict(list)
    for i, r in enumerate(records):
        by_g[r["gid"]].append(i)
    gids = np.array(list(by_g))
    Z = {m: [] for m in dims}
    rng = np.random.default_rng(0)
    # feature standardisation statistics are not used: adapters see raw native features.
    for ep in range(cfg.epochs):
        rng.shuffle(gids)
        tot = 0.0
        for s in range(0, len(gids), cfg.batch_size):
            idx = [i for g in gids[s:s + cfg.batch_size] for i in by_g[g]]
            H, G, rec = [], [], 0.0
            for m in dims:
                sel = [i for i in idx if records[i]["iface"] == m]
                if not sel:
                    continue
                z = torch.as_tensor(np.stack([records[i]["z"] for i in sel]), dtype=torch.float32, device=dev)
                h = model.embed(m, z)
                a = sparse_code_torch(h.detach(), model.D.detach(), cfg.lambda_1, cfg.ista_iters)
                Da = a @ model.D.T
                rec = rec + cfg.lambda_h * ((h - Da) ** 2).sum(1).mean()
                rec = rec + cfg.lambda_z * ((z - Da @ model.B[model._k(m)].T) ** 2).sum(1).mean()
                rec = rec + cfg.lambda_1 * a.sum(1).mean()
                H.append(h)
                G.append(torch.as_tensor([records[i]["gid"] for i in sel], device=dev))
            loss = rec
            if use_alignment and H:
                loss = loss + info_nce(torch.cat(H), torch.cat(G), cfg.tau_nce)
            opt.zero_grad()
            loss.backward()
            opt.step()
            model.project()
            tot += float(loss)
        log(f"[concepts] epoch {ep + 1}/{cfg.epochs} loss {tot:.4f}")
    return model
