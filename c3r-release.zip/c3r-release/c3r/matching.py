"""Ground-truth-anchored one-to-one matching (Eq. 2)."""
from __future__ import annotations

import numpy as np
from scipy.optimize import linear_sum_assignment


def box_iou(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Pairwise IoU between boxes in xyxy format. a: (N,4), b: (M,4) -> (N,M)."""
    a = np.asarray(a, dtype=np.float64).reshape(-1, 4)
    b = np.asarray(b, dtype=np.float64).reshape(-1, 4)
    if len(a) == 0 or len(b) == 0:
        return np.zeros((len(a), len(b)))
    tl = np.maximum(a[:, None, :2], b[None, :, :2])
    br = np.minimum(a[:, None, 2:], b[None, :, 2:])
    wh = np.clip(br - tl, 0, None)
    inter = wh[..., 0] * wh[..., 1]
    area_a = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1])
    area_b = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
    return inter / np.clip(area_a[:, None] + area_b[None, :] - inter, 1e-12, None)


def match_objects(gt_boxes: np.ndarray, det_boxes: np.ndarray, kappa: float):
    """Hungarian matching maximising total IoU (Eq. 2).

    Returns
    -------
    assign : (G,) int array, candidate index for each annotated object or -1.
    valid  : (G,) bool array, v_m^(t)(g) = 1{IoU >= kappa}.
    ious   : (G,) float array, IoU of the assigned candidate (0 if none).
    """
    G = len(gt_boxes)
    assign = -np.ones(G, dtype=int)
    ious = np.zeros(G)
    if G == 0 or len(det_boxes) == 0:
        return assign, np.zeros(G, bool), ious
    iou = box_iou(gt_boxes, det_boxes)
    rows, cols = linear_sum_assignment(-iou)
    for r, c in zip(rows, cols):
        if iou[r, c] > 0:
            assign[r] = c
            ious[r] = iou[r, c]
    valid = (assign >= 0) & (ious >= kappa)
    return assign, valid, ious
