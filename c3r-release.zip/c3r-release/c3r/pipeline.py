"""End-to-end C3R pipeline. Each stage reads the outputs of earlier stages from `output_dir`
and writes its own, so stages can be re-run independently (see scripts/run_all.sh).

Stages
  splits      disjoint dev / cal / test image ids                         (Table III)
  robustness  thresholded COCO AP under corruption severities 0-5          (Fig. 4)
  extract     matched clean/adverse development features for all detectors
  concepts    adapters + shared dictionary, priors, K_env, exemplars, CRAFT
  explain     main + audit explanations of sampled object-concept pairs    (Tables V, VI, IX)
  baselines   saliency/CRAFT concept scores, deletion/insertion AUC        (Table IV)
  adverse     clean-adverse-restored triplets and failure diagnosis        (Tables VII, VIII)
  cross       cross-detector agreement and cost                            (Table XI)
  evaluate    all tables (IV-XI) as CSV and LaTeX
"""
from __future__ import annotations

import json
import pickle
import time
from collections import defaultdict
from pathlib import Path

import numpy as np

from .seeding import set_base_seed, stream

PRIMARY = "faster_rcnn"


# ============================================================================ helpers
def out_dir(cfg) -> Path:
    p = Path(cfg.output_dir)
    p.mkdir(parents=True, exist_ok=True)
    return p


def save(obj, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(obj, f)


def load(path):
    with open(path, "rb") as f:
        return pickle.load(f)


def log(*a):
    print(time.strftime("[%H:%M:%S]"), *a, flush=True)


def _detector(cfg, name):
    from .detectors.base import build_detector
    d = build_detector(name, cfg.detectors, cfg.device)
    d.score_threshold = cfg.detectors.score_threshold
    return d


def _sets(cfg):
    from .data.coco import CocoSet, load_splits
    splits = load_splits(out_dir(cfg) / "splits.json")
    train = CocoSet(cfg.data.coco_root, "train2017", cfg.data.min_box_side)
    val = CocoSet(cfg.data.coco_root, "val2017", cfg.data.min_box_side)
    return splits, {"dev": train, "cal": val, "test": val}


def _cond_for(obj_id, conditions):
    return conditions[int(stream("condition", obj_id).integers(len(conditions)))]


def _triplet(img, img_id, condition, severity):
    from .data.corruptions import make_triplet
    return make_triplet(img, condition, severity, stream("corrupt", img_id, condition, severity))


# ============================================================================ splits
def stage_splits(cfg):
    from .data.coco import make_splits
    s = make_splits(cfg.data.coco_root, cfg.data.n_dev_images, cfg.data.n_cal_images, cfg.data.n_test_images,
                    out_dir(cfg) / "splits.json", cfg.data.min_box_side)
    log("splits:", {k: len(v) for k, v in s.items()})


# ============================================================================ robustness (Fig. 4)
def stage_robustness(cfg):
    from pycocotools.coco import COCO
    from pycocotools.cocoeval import COCOeval

    from .data.corruptions import corrupt
    splits, sets = _sets(cfg)
    gt = COCO(str(Path(cfg.data.coco_root) / "annotations" / "instances_val2017.json"))
    rows = []
    for name in cfg.detectors.names:
        det = _detector(cfg, name)
        for cond in cfg.adverse.conditions:
            for sev in cfg.adverse.severities:
                res = []
                for iid in splits["test"]:
                    img, *_ = sets["test"].load(iid)
                    x = corrupt(img, cond, sev, stream("corrupt", iid, cond, sev))
                    d = det.detect(x)
                    for b, s, l in zip(d.boxes, d.scores, d.labels):
                        res.append({"image_id": iid, "category_id": int(l), "score": float(s),
                                    "bbox": [float(b[0]), float(b[1]), float(b[2] - b[0]), float(b[3] - b[1])]})
                ap = 0.0
                if res:
                    E = COCOeval(gt, gt.loadRes(res), "bbox")
                    E.params.imgIds = splits["test"]
                    E.evaluate(); E.accumulate(); E.summarize()
                    ap = float(E.stats[0])
                rows.append({"detector": name, "condition": cond, "severity": sev, "AP": ap})
                log(name, cond, sev, f"AP={ap:.4f}")
    save(rows, out_dir(cfg) / "robustness.pkl")


# ============================================================================ extract
def stage_extract(cfg):
    """Matched clean (and one corrupted view, for K_env) development features for every detector."""
    from .matching import match_objects
    splits, sets = _sets(cfg)
    S = cfg.adverse.anchor_severity
    for name in cfg.detectors.names:
        det = _detector(cfg, name)
        recs = []
        for n, iid in enumerate(splits["dev"]):
            img, boxes, cats, ann_ids = sets["dev"].load(iid)
            cond = _cond_for(iid, cfg.adverse.conditions)
            _, adv, _ = _triplet(img, iid, cond, S)
            dc, da = det.detect(img), det.detect(adv)
            ac, vc, _ = match_objects(boxes, dc.boxes, cfg.matching.kappa)
            aa, va, _ = match_objects(boxes, da.boxes, cfg.matching.kappa)
            for g in range(len(boxes)):
                if not vc[g]:
                    continue
                c = ac[g]
                x1, y1, x2, y2 = boxes[g].astype(int)
                crop = img[max(y1, 0):y2, max(x1, 0):x2]
                r = {"gid": int(ann_ids[g]), "image_id": iid, "iface": dc.iface[c], "z": np.asarray(dc.feats[c]),
                     "cls": int(cats[g]), "pred": int(dc.labels[c]), "correct": int(dc.labels[c]) == int(cats[g]),
                     "crop": None if name != PRIMARY else _small(crop)}
                if va[g] and da.iface[aa[g]] == dc.iface[c]:
                    r["z_adv"] = np.asarray(da.feats[aa[g]])
                recs.append(r)
            if n % 200 == 0:
                log(name, f"extract {n}/{len(splits['dev'])}, records={len(recs)}")
        save(recs, out_dir(cfg) / f"extract_{name}.pkl")


def _small(crop, size=96):
    import cv2
    if crop.size == 0:
        return None
    return cv2.resize(crop, (size, size))


# ============================================================================ concepts
def stage_concepts(cfg, ablation="full"):
    from .baselines.craft import CraftBaseline
    from .concepts.alignment import train_concept_space
    from .concepts.priors import class_priors, environmental_concepts
    from .contrast import confusion_from_dev
    from .detectors.base import COCO80
    from .image_edits import build_exemplar_bank
    import torch

    names = cfg.detectors.names if ablation != "no_alignment" else [PRIMARY]
    recs = []
    for name in names:
        recs += load(out_dir(cfg) / f"extract_{name}.pkl")
    cs = train_concept_space(recs, cfg.concepts, cfg.device, use_alignment=ablation != "no_alignment", log=log)
    prim = [r for r in recs if r["iface"] == PRIMARY]
    Z = np.stack([r["z"] for r in prim])
    A = cs.code(PRIMARY, Z, cfg.concepts.lambda_1, cfg.concepts.ista_iters)
    labels = np.array([r["cls"] for r in prim])
    correct = np.array([r["correct"] for r in prim])
    pi, mu = class_priors(A, labels, correct, cfg.concepts.eta_a)
    conf = confusion_from_dev(labels, np.array([r["pred"] for r in prim]), COCO80)
    both = [i for i, r in enumerate(prim) if "z_adv" in r]
    A_adv = cs.code(PRIMARY, np.stack([prim[i]["z_adv"] for i in both]), cfg.concepts.lambda_1, cfg.concepts.ista_iters)
    env = environmental_concepts(A[both], A_adv)
    bank = build_exemplar_bank([(r["crop"], a, r["cls"]) for r, a in zip(prim, A) if r["crop"] is not None],
                               cfg.concepts.K)
    craft = CraftBaseline(cfg.concepts.K, cfg.seed).fit(Z, A, cfg.baselines.craft_c_min)
    tag = "" if ablation == "full" else f"_{ablation}"
    torch.save(cs.state_dict(), out_dir(cfg) / f"concept_space{tag}.pt")
    save({"dims": {m: d for m, d in _dims(recs).items()}, "pi": pi, "mu": mu, "confusion": conf, "env": env,
          "bank": bank, "craft": craft}, out_dir(cfg) / f"concepts{tag}.pkl")
    log("concepts: K_env =", env.tolist(), "| CRAFT matched concepts:", sorted(craft.keep))


def _dims(recs):
    d = {}
    for r in recs:
        d.setdefault(r["iface"], len(r["z"]))
    return d


def load_concepts(cfg, ablation="full"):
    import torch
    from .concepts.alignment import ConceptSpace
    tag = "_no_alignment" if ablation == "no_alignment" else ""
    meta = load(out_dir(cfg) / f"concepts{tag}.pkl")
    cs = ConceptSpace(meta["dims"], cfg.concepts.embed_dim, cfg.concepts.K)
    cs.load_state_dict(torch.load(out_dir(cfg) / f"concept_space{tag}.pt", map_location="cpu"))
    dev = "cuda" if (cfg.device == "cuda" and torch.cuda.is_available()) else "cpu"
    return cs.to(dev).eval(), meta


def make_explainer(cfg, det, ablation="full"):
    from .explain import Explainer
    cs, meta = load_concepts(cfg, ablation)
    with open(Path(cfg.data.coco_root) / "annotations" / "instances_val2017.json", encoding="utf-8") as f:
        supercat = {c["id"]: c["supercategory"] for c in json.load(f)["categories"]}
    return Explainer(det, cs, (meta["pi"], meta["mu"]), meta["confusion"], supercat, meta["env"], meta["bank"],
                     cfg, ablation), meta


# ============================================================================ explain
def _object_pool(cfg, split, sets, splits):
    """All annotated objects of the split with the condition they are evaluated under
    (clean, or the object's adverse condition at the anchor severity)."""
    pool = []
    for iid in splits[split]:
        boxes, cats, ann_ids = _meta(sets[split], iid)
        for g in range(len(boxes)):
            for cond in ("clean", _cond_for(int(ann_ids[g]), cfg.adverse.conditions)):
                pool.append((iid, g, int(ann_ids[g]), cond))
    return pool


def _meta(cset, iid):
    anns = cset.anns.get(iid, [])
    return (np.array([a["box"] for a in anns], float).reshape(-1, 4), np.array([a["cat"] for a in anns], int),
            np.array([a["ann_id"] for a in anns], int))


def stage_explain(cfg, split="test", ablation="full", n_pairs=None):
    """Explain sampled (object, condition, concept) instances with the main stream and, for the
    full configuration, re-execute each with the independent audit stream."""
    from .interventions import margin_from_out, recovery
    from .matching import box_iou
    splits, sets = _sets(cfg)
    det = _detector(cfg, PRIMARY)
    ex, _ = make_explainer(cfg, det, ablation)
    n_pairs = n_pairs or cfg.roles.n_audit_instances
    K = cfg.concepts.K
    pool = _object_pool(cfg, split, sets, splits)
    rng = stream("sample", split)
    order = rng.permutation(len(pool))
    by_obj = defaultdict(list)
    per_obj = 4                                            # concepts sampled per object instance
    for i in order:
        if sum(len(v) for v in by_obj.values()) >= n_pairs * 1.6:  # oversample; invalid matches are skipped
            break
        by_obj[pool[i]] = list(stream("concepts", pool[i][2], pool[i][3]).choice(K, per_obj, replace=False))
    rows, S = [], cfg.adverse.anchor_severity
    audit = load(out_dir(cfg) / f"explain_{split}_full.pkl") if ablation != "full" else None
    audit_map = {(r["obj_id"], r["condition"], r["k"]): r for r in audit} if audit else {}
    for (iid, g, oid, cond), ks in by_obj.items():
        if len(rows) >= n_pairs:
            break
        img, boxes, cats, _ = sets[split].load(iid)
        dc, ac, vc, _ = ex.match(img, boxes)
        if not vc[g]:
            continue
        clean_ctx = ex.context(img, dc, ac[g], boxes[g], cats[g], obj_id=oid, condition="clean")
        ctx, rec = clean_ctx, {"rec_M": np.nan, "rec_L": np.nan}
        if cond != "clean":
            _, adv, rst = _triplet(img, iid, cond, S)
            da, aa, va, _ = ex.match(adv, boxes)
            dr, ar, vr, _ = ex.match(rst, boxes)
            if not (va[g] and vr[g]):
                continue
            ctx = ex.context(adv, da, aa[g], boxes[g], cats[g], y_alt=clean_ctx["y_alt"], a_clean=clean_ctx["a"],
                             obj_id=oid, condition=cond)
            M = [margin_from_out({"probs": d.probs[[c]]}, ctx["y_idx"], ctx["alt_idx"], 1e-6)[0]
                 for d, c in ((dc, ac[g]), (da, aa[g]), (dr, ar[g]))]
            L = [box_iou(d.boxes[[c]], boxes[[g]])[0, 0] for d, c in ((dc, ac[g]), (da, aa[g]), (dr, ar[g]))]
            rec = {"rec_M": recovery(*M, cfg.adverse.eps_M), "rec_L": recovery(*L, cfg.adverse.eps_L)}
        for k in ks:
            r = ex.explain_pair(ctx, int(k), "main")
            r.update(obj_id=oid, image_id=iid, condition=cond, y_ref=ctx["y_ref"], y_alt=ctx["y_alt"], **rec)
            if ablation == "full":
                a = ex.explain_pair(ctx, int(k), "audit")
                r.update(audit_role=a["role"], audit_valid=a["valid"], audit_aie=a["aie"], audit_iou_loss=a["iou_loss"])
            else:
                a = audit_map.get((oid, cond, int(k)))
                if a is None:
                    continue
                r.update(audit_role=a["audit_role"], audit_valid=a["audit_valid"], audit_aie=a["audit_aie"],
                         audit_iou_loss=a["audit_iou_loss"])
            rows.append(r)
        log(f"explain[{split}/{ablation}] {len(rows)}/{n_pairs}")
    save(rows[:n_pairs], out_dir(cfg) / f"explain_{split}_{ablation}.pkl")


# ============================================================================ baselines (Table IV)
def stage_baselines(cfg, split="test"):
    """Concept-level scores Psi^E for every baseline on the explained pairs of `split`, plus
    deletion/insertion AUCs per object. Run for `dev` too: dead-zones delta^E are fixed there."""
    from .baselines.del_ins import c3r_ranking_map, deletion_insertion
    from .baselines.saliency import drise, gradcampp, scorecam
    from .metrics import concept_score_from_saliency, matched_control_masks
    from .metrics import concept_mask as cmask
    splits, sets = _sets(cfg)
    det = _detector(cfg, PRIMARY)
    ex, meta = make_explainer(cfg, det)
    craft = meta["craft"]
    rows = load(out_dir(cfg) / f"explain_{split}_full.pkl")
    by_obj = defaultdict(list)
    for r in rows:
        by_obj[(r["image_id"], r["obj_id"], r["condition"])].append(r)
    out, aucs = [], []
    for (iid, oid, cond), rs in by_obj.items():
        img, boxes, cats, ann_ids = sets[split].load(iid)
        g = int(np.where(ann_ids == oid)[0][0])
        x = img if cond == "clean" else _triplet(img, iid, cond, cfg.adverse.anchor_severity)[1]
        d, a, v, _ = ex.match(x, boxes)
        if not v[g]:
            continue
        ctx = ex.context(x, d, a[g], boxes[g], cats[g], y_alt=rs[0]["y_alt"], obj_id=oid, condition=cond)
        h, box = ctx["handle"], ctx["det_box"]
        x1, y1, x2, y2 = [int(round(t)) for t in box]
        x1, y1 = max(x1, 0), max(y1, 0)
        rng = stream("baseline", oid, cond)
        sal = {"gradcampp": gradcampp(det, x, h, ctx["y_ref"], ctx["y_alt"]),
               "scorecam": scorecam(det, x, h, ctx["y_ref"], ctx["y_alt"], cfg.baselines.scorecam_channels),
               "drise": drise(det, x, h, ctx["y_idx"], ctx["alt_idx"], box, rng, cfg.baselines.drise_masks,
                              cfg.baselines.drise_grid, cfg.baselines.drise_p)}
        crop = {m: s[y1:y2, x1:x2] for m, s in sal.items()}
        head = det.head_fn(h)
        for r in rs:
            k = r["k"]
            m = cmask(ctx["maps"][k], cfg.intervention.mask_quantile)
            ctrls = matched_control_masks(m, cfg.intervention.max_regions, rng)
            row = {"obj_id": oid, "image_id": iid, "condition": cond, "k": k, "c3r": r["aie"]}
            for meth, S in crop.items():
                S = S[:m.shape[0], :m.shape[1]]
                mm = m[:S.shape[0], :S.shape[1]]
                row[meth] = concept_score_from_saliency(S, mm, [c[:S.shape[0], :S.shape[1]] for c in ctrls])
            row["craft"] = craft.concept_effect(ctx["z"], head, ctx["y_idx"], ctx["alt_idx"], k)
            out.append(row)
        if split == "test":
            aie = np.zeros(cfg.concepts.K)
            for r in rs:
                aie[r["k"]] = r["aie"]
            rank = {"c3r": c3r_ranking_map(ctx["maps"], aie), **crop}
            # CRAFT ranking: concept maps weighted by CRAFT effects of the matched concepts
            ce = np.array([np.nan_to_num(craft.concept_effect(ctx["z"], head, ctx["y_idx"], ctx["alt_idx"], k))
                           for k in range(cfg.concepts.K)])
            rank["craft"] = c3r_ranking_map(ctx["maps"], ce)
            for meth, rm in rank.items():
                dl, ins = deletion_insertion(det, x, h, box, rm, ctx["y_idx"])
                aucs.append({"obj_id": oid, "image_id": iid, "method": meth, "del": dl, "ins": ins})
        log(f"baselines[{split}] objects done: {len({(o['obj_id'], o['condition']) for o in out})}")
    save({"scores": out, "aucs": aucs}, out_dir(cfg) / f"baselines_{split}.pkl")


# ============================================================================ adverse (Tables VII, VIII)
def _triplet_record(ex, cfg, sets, split, iid, g, cond, with_failure: bool, tag_streams=("main", "audit")):
    from .adverse import failure_vector
    from .interventions import insertion_gain, margin_from_out, missing_deficit, recovery, removal_intervention
    from .matching import box_iou
    img, boxes, cats, ann_ids = sets[split].load(iid)
    oid = int(ann_ids[g])
    trip = _triplet(img, iid, cond, cfg.adverse.anchor_severity)
    m = [ex.match(x, boxes) for x in trip]
    if not all(v[g] for _, _, v, _ in m):
        return {"valid": False, "obj_id": oid, "condition": cond}
    ctxs = []
    for t, (x, (d, a, _, _)) in enumerate(zip(trip, m)):
        y_alt = ctxs[0]["y_alt"] if ctxs else None
        a_clean = ctxs[0]["a"] if ctxs else None
        ctxs.append(ex.context(x, d, a[g], boxes[g], cats[g], y_alt=y_alt, a_clean=a_clean, obj_id=oid,
                               condition=f"{cond}:{'car'[t]}"))
    M = [margin_from_out({"probs": d.probs[[a[g]]]}, ctxs[0]["y_idx"], ctxs[0]["alt_idx"], 1e-6)[0]
         for d, a, _, _ in m]
    L = [box_iou(d.boxes[[a[g]]], boxes[[g]])[0, 0] for d, a, _, _ in m]
    rec = {"valid": True, "obj_id": oid, "image_id": iid, "condition": cond, "M": M, "L": L,
           "rec_M": recovery(*M, cfg.adverse.eps_M), "rec_L": recovery(*L, cfg.adverse.eps_L)}
    # missing-role rate under the adverse input
    ex.det.prepare(trip[1])
    c = ctxs[1]
    miss_any = False
    for k in range(cfg.concepts.K):
        r = ex.explain_pair(c, k, "main", with_image=False)
        dk = r["d"]
        if dk > cfg.missing.delta_a and r["U_plus"] > cfg.roles.delta_M:
            r = ex.explain_pair(c, k, "main", with_image=True)
            if r["miss"]:
                miss_any = True
                break
    rec["missing_any"] = miss_any
    if with_failure:
        iv = cfg.intervention
        for tag in tag_streams:
            per = {}
            for t in (0, 1):
                ex.det.prepare(trip[t])
                cx = ctxs[t]
                head = ex.det.head_fn(cx["handle"])
                aie, var = np.zeros(cfg.concepts.K), np.zeros(cfg.concepts.K)
                for k in range(cfg.concepts.K):
                    rr = removal_intervention(cx["z"], cx["a"], k, cx["BD"], head, cx["y_idx"], cx["alt_idx"],
                                              iv.doses, iv.n_controls, stream(tag, oid, cx["condition"], k),
                                              cx["gt_box"], cx["d_img"], iv.epsilon, n_boot=50)
                    aie[k], var[k] = rr.aie, rr.var_rep
                per[t] = (aie, var)
            ex.det.prepare(trip[1])
            head_a = ex.det.head_fn(ctxs[1]["handle"])
            U = np.array([insertion_gain(ctxs[1]["z"], ctxs[1]["a"], k,
                                         missing_deficit(ctxs[1]["a"][k], 1.0, ex.mu.get(ctxs[0]["y_ref"], np.zeros(cfg.concepts.K))[k], 0.0),
                                         ctxs[1]["BD"], head_a, ctxs[1]["y_idx"], ctxs[1]["alt_idx"],
                                         cfg.missing.beta_in, cfg.missing.d_max) for k in range(cfg.concepts.K)])
            logp = [np.log(d.probs[a[g], ctxs[0]["alt_idx"]] + 1e-6) for d, a, _, _ in m]
            env = np.array(sorted(ex.env), int)
            obj = np.array([k for k in range(cfg.concepts.K) if k not in ex.env], int)
            rec[f"gamma_{tag}"] = failure_vector(dict(
                a_c=ctxs[0]["a"], a_a=ctxs[1]["a"], logp_alt_a=logp[1], logp_alt_r=logp[2], U_plus_a=U,
                L_c=L[0], L_a=L[1], L_r=L[2], aie_c=per[0][0], aie_a=per[1][0], var_c=per[0][1], var_a=per[1][1],
                env=env, obj=obj))
    return rec


def stage_adverse(cfg):
    splits, sets = _sets(cfg)
    det = _detector(cfg, PRIMARY)
    ex, _ = make_explainer(cfg, det)
    results = {}
    for cond in cfg.adverse.conditions:
        objs = [(iid, g) for iid in splits["test"] for g in range(len(_meta(sets["test"], iid)[0]))]
        sel = stream("adverse_candidates", cond).choice(len(objs), min(cfg.adverse.candidates_per_condition, len(objs)),
                                                        replace=False)
        recs = []
        for i in sel:
            iid, g = objs[i]
            recs.append(_triplet_record(ex, cfg, sets, "test", iid, g, cond, with_failure=False))
        results[cond] = recs
        log(f"adverse[{cond}] valid {sum(r['valid'] for r in recs)}/{len(recs)}")
    save(results, out_dir(cfg) / "adverse_triplets.pkl")
    # failure diagnosis: development cases fix the scaling; 250 audited test cases are evaluated
    fail = {}
    for split, n in (("dev", cfg.roles.n_failure_cases), ("test", cfg.roles.n_failure_cases)):
        objs = [(iid, g) for iid in splits[split] for g in range(len(_meta(sets[split], iid)[0]))]
        rng = stream("failure_cases", split)
        out = []
        for i in rng.permutation(len(objs)):
            if len(out) >= n:
                break
            iid, g = objs[i]
            cond = cfg.adverse.conditions[int(rng.integers(len(cfg.adverse.conditions)))]
            r = _triplet_record(ex, cfg, sets, split, iid, g, cond, with_failure=True)
            if r["valid"]:
                out.append(r)
        fail[split] = out
        log(f"failure cases [{split}] {len(out)}")
    save(fail, out_dir(cfg) / "failure_cases.pkl")


# ============================================================================ cross-detector (Table XI)
def stage_cross(cfg, max_images=None):
    import torch

    from .cross_detector import concept_match_coverage, mask_iou, mean_spearman, sign_agreement
    from .interventions import removal_intervention
    from .metrics import concept_mask
    splits, sets = _sets(cfg)
    dets = {n: _detector(cfg, n) for n in cfg.detectors.names}
    exs = {n: make_explainer(cfg, d)[0] for n, d in dets.items()}
    names = cfg.detectors.names
    pairs = [(names[i], names[j]) for i in range(len(names)) for j in range(i + 1, len(names))]
    acc = {p: defaultdict(list) for p in pairs}
    iv = cfg.intervention
    for iid in splits["test"][:max_images]:
        img, boxes, cats, ann_ids = sets["test"].load(iid)
        for (m, n) in pairs:
            if torch.cuda.is_available():
                torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats()
            t0 = time.perf_counter()
            per = {}
            for name in (m, n):
                ex = exs[name]
                d, a, v, _ = ex.match(img, boxes)
                per[name] = (d, a, v)
            shared = [g for g in range(len(boxes)) if per[m][2][g] and per[n][2][g]]
            y_alt = {}
            for g in shared:
                res = {}
                for name in (m, n):
                    ex = exs[name]
                    d, a, _ = per[name]
                    ctx = ex.context(img, d, a[g], boxes[g], cats[g], y_alt=y_alt.get(g), obj_id=int(ann_ids[g]))
                    y_alt.setdefault(g, ctx["y_alt"])
                    head = ex.det.head_fn(ctx["handle"])
                    aie = np.array([removal_intervention(ctx["z"], ctx["a"], k, ctx["BD"], head, ctx["y_idx"],
                                                         ctx["alt_idx"], iv.doses, iv.n_controls,
                                                         stream("main", int(ann_ids[g]), "clean", k), ctx["gt_box"],
                                                         ctx["d_img"], iv.epsilon, n_boot=50).aie
                                    for k in range(cfg.concepts.K)])
                    res[name] = (ctx["a"], aie, ctx["maps"])
                (am, em, mm), (an, en, mn) = res[m], res[n]
                acc[(m, n)]["A_m"].append(am); acc[(m, n)]["A_n"].append(an)
                acc[(m, n)]["aie_m"].append(em); acc[(m, n)]["aie_n"].append(en)
                act = np.where((am > cfg.concepts.eta_a) & (an > cfg.concepts.eta_a))[0]
                for k in act:
                    m1 = concept_mask(mm[k], iv.mask_quantile)
                    m2 = concept_mask(mn[k], iv.mask_quantile)
                    h, w = min(m1.shape[0], m2.shape[0]), min(m1.shape[1], m2.shape[1])
                    acc[(m, n)]["iou"].append(mask_iou(m1[:h, :w], m2[:h, :w]))
            if torch.cuda.is_available():
                torch.cuda.synchronize()
                acc[(m, n)]["mem"].append(torch.cuda.max_memory_allocated() / 2**30)
            acc[(m, n)]["ms"].append((time.perf_counter() - t0) * 1000)
            acc[(m, n)]["n"].append(len(shared))
    rows = []
    for (m, n), a in acc.items():
        A_m, A_n = np.array(a["A_m"]), np.array(a["A_n"])
        E_m, E_n = np.array(a["aie_m"]), np.array(a["aie_n"])
        rows.append({"pair": f"{m}<->{n}", "n": int(sum(a["n"])),
                     "coverage": concept_match_coverage(A_m, A_n, cfg.concepts.eta_a),
                     "spearman": mean_spearman(np.abs(E_m), np.abs(E_n)),
                     "sign": sign_agreement(E_m.ravel(), E_n.ravel(), cfg.roles.delta_M),
                     "mask_iou": float(np.nanmean(a["iou"])) if a["iou"] else float("nan"),
                     "latency_ms": float(np.mean(a["ms"])), "vram_gb": float(np.max(a["mem"])) if a["mem"] else float("nan")})
        log(rows[-1])
    save(rows, out_dir(cfg) / "cross_detector.pkl")


def run_stage(cfg, stage, **kw):
    set_base_seed(cfg.seed)
    fn = {"splits": stage_splits, "robustness": stage_robustness, "extract": stage_extract,
          "concepts": stage_concepts, "explain": stage_explain, "baselines": stage_baselines,
          "adverse": stage_adverse, "cross": stage_cross}
    if stage == "evaluate":
        from .evaluate import evaluate_all
        return evaluate_all(cfg)
    return fn[stage](cfg, **kw)
