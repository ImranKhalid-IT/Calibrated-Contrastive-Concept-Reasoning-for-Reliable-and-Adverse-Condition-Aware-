"""Configuration loading with dotted access and command-line overrides."""
from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

import yaml


class Cfg(dict):
    """Dictionary with attribute access (cfg.roles.delta_M)."""

    def __getattr__(self, key: str) -> Any:
        try:
            v = self[key]
        except KeyError as e:
            raise AttributeError(key) from e
        return Cfg(v) if isinstance(v, dict) and not isinstance(v, Cfg) else v

    def __setattr__(self, key: str, value: Any) -> None:
        self[key] = value


def _set(d: dict, dotted: str, value: Any) -> None:
    keys = dotted.split(".")
    for k in keys[:-1]:
        d = d.setdefault(k, {})
    d[keys[-1]] = value


def load_config(path: str | Path = "configs/default.yaml", overrides: list[str] | None = None) -> Cfg:
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    for ov in overrides or []:
        key, val = ov.split("=", 1)
        _set(cfg, key, yaml.safe_load(val))
    return _wrap(cfg)


def _wrap(d: Any) -> Any:
    if isinstance(d, dict):
        return Cfg({k: _wrap(v) for k, v in d.items()})
    if isinstance(d, list):
        return [_wrap(v) for v in d]
    return d


def save_config(cfg: dict, path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(json.loads(json.dumps(copy.deepcopy(cfg))), f, sort_keys=False)
