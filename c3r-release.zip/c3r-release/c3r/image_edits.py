"""Image-space concept maps, removal/insertion edits and matched spatial controls.

* Concept activation maps (Eq. 37) are obtained by occlusion: each cell of a grid over the
  matched box is blurred and the drop of every concept coefficient at the same candidate is
  recorded, then bilinearly upsampled to the box.
* Image-level removal blends the concept mask Omega_gk with a strongly blurred copy at dose alpha;
  matched controls blur random regions of identical area inside the box.
* Image-level insertion pastes a development exemplar of concept k into the box; its control
  pastes a phase-scrambled exemplar (same amplitude spectrum / energy, no semantic content).
Every edit is re-evaluated at the same candidate and kept only if the candidate box still
matches the ground truth at IoU >= kappa.
"""
from __future__ import annotations

import cv2
import numpy as np

from .interventions import integrate_dose, margin_from_out
from .matching import box_iou
from .metrics import concept_mask, matched_control_masks


def _box_int(box, hw):
    x1, y1, x2, y2 = box
    H, W = hw
    x1, y1 = int(np.clip(np.floor(x1), 0, W - 1)), int(np.clip(np.floor(y1), 0, H - 1))
    x2, y2 = int(np.clip(np.ceil(x2), x1 + 1, W)), int(np.clip(np.ceil(y2), y1 + 1, H))
    return x1, y1, x2, y2


def _blurred(img, sigma=12):
    return cv2.GaussianBlur(img, (0, 0), sigma)


def concept_maps(det, img, handle, code_fn, gt_box, grid=7):
    """Returns (K, h, w) nonnegative concept activation maps over the matched box crop and the
    clean code a (K,)."""
    x1, y1, x2, y2 = _box_int(gt_box, img.shape[:2])
    h, w = y2 - y1, x2 - x1
    blur = _blurred(img)
    ys, xs = np.linspace(y1, y2, grid + 1).astype(int), np.linspace(x1, x2, grid + 1).astype(int)
    edits = []
    for i in range(grid):
        for j in range(grid):
            e = img.copy()
            e[ys[i]:max(ys[i + 1], ys[i] + 1), xs[j]:max(xs[j + 1], xs[j] + 1)] = \
                blur[ys[i]:max(ys[i + 1], ys[i] + 1), xs[j]:max(xs[j + 1], xs[j] + 1)]
            edits.append(e)
    Z0, _ = det.features_at([img], handle)
    a0 = code_fn(Z0)[0]
    Z, _ = det.features_at(edits, handle)
    A = code_fn(Z)                                   # (grid*grid, K)
    drop = np.maximum(a0[None] - A, 0).T.reshape(-1, grid, grid).astype(np.float32)
    maps = np.stack([cv2.resize(m, (w, h), interpolation=cv2.INTER_LINEAR) for m in drop])
    return maps, a0


def _apply_region(img, src, box, mask, alpha):
    x1, y1, x2, y2 = box
    out = img.copy()
    roi = out[y1:y2, x1:x2].astype(np.float32)
    s = src[y1:y2, x1:x2].astype(np.float32)
    m = mask[..., None].astype(np.float32) * alpha
    out[y1:y2, x1:x2] = np.clip(roi * (1 - m) + s * m, 0, 255).astype(np.uint8)
    return out


def _valid(out, gt_box, kappa):
    return box_iou(out["box"], gt_box[None])[:, 0] >= kappa


def image_removal(det, img, handle, gt_box, cmap, q, doses, y_idx, alt_idx, rng, n_rep, n_ctrl,
                  kappa, max_regions=5, eps=1e-6):
    """Image-level controlled removal effects for one concept.

    Returns (rep_effects[R], valid_fraction, mask). rep_effects are dose-integrated controlled
    effects per replicate (used for G^- in Eq. 15 and for the audit re-execution)."""
    bx = _box_int(gt_box, img.shape[:2])
    mask = concept_mask(cmap, q)
    if not mask.any():
        return np.zeros(n_rep), 0.0, mask
    _, out0 = det.features_at([img], handle)
    M0 = margin_from_out(out0, y_idx, alt_idx, eps)[0]
    reps, valid_all = [], []
    for r in range(n_rep):
        blur = _blurred(img, sigma=float(rng.uniform(9, 15)))
        ctrl = matched_control_masks(mask, max(1, min(n_ctrl, max_regions)), rng)
        imgs = []
        for a in doses:
            imgs.append(_apply_region(img, blur, bx, mask, a))
            imgs += [_apply_region(img, blur, bx, c, a) for c in ctrl]
        _, out = det.features_at(imgs, handle)
        M = margin_from_out(out, y_idx, alt_idx, eps).reshape(len(doses), 1 + len(ctrl))
        valid_all.append(_valid(out, gt_box, kappa).mean())
        eff = (M0 - M[:, 0]) - (M0 - M[:, 1:]).mean(1)
        reps.append(integrate_dose(np.asarray(doses), eff))
    return np.array(reps), float(np.mean(valid_all)), mask


def phase_scramble(patch, rng):
    f = np.fft.fft2(patch.astype(np.float32), axes=(0, 1))
    ph = np.angle(np.fft.fft2(rng.random(patch.shape[:2]).astype(np.float32)))[..., None]
    out = np.real(np.fft.ifft2(np.abs(f) * np.exp(1j * (np.angle(f) + ph)), axes=(0, 1)))
    return np.clip(out, 0, 255).astype(np.uint8)


def image_insertion(det, img, handle, gt_box, exemplar, beta, y_idx, alt_idx, rng, n_rep, kappa,
                    frac=0.25, eps=1e-6):
    """Image-level insertion of an exemplar patch of concept k (covering <= frac of the box)
    against a phase-scrambled control. Returns (rep_gains[R], valid_fraction)."""
    if exemplar is None:
        return np.zeros(n_rep), 0.0
    x1, y1, x2, y2 = _box_int(gt_box, img.shape[:2])
    bw, bh = x2 - x1, y2 - y1
    pw, ph = max(2, int(bw * np.sqrt(frac))), max(2, int(bh * np.sqrt(frac)))
    patch = cv2.resize(exemplar, (pw, ph))
    _, out0 = det.features_at([img], handle)
    M0 = margin_from_out(out0, y_idx, alt_idx, eps)[0]
    gains, valid = [], []
    for _ in range(n_rep):
        px, py = x1 + rng.integers(0, bw - pw + 1), y1 + rng.integers(0, bh - ph + 1)
        ctrl = phase_scramble(patch, rng)
        ims = []
        for p in (patch, ctrl):
            e = img.copy().astype(np.float32)
            e[py:py + ph, px:px + pw] = (1 - beta) * e[py:py + ph, px:px + pw] + beta * p
            ims.append(np.clip(e, 0, 255).astype(np.uint8))
        _, out = det.features_at(ims, handle)
        M = margin_from_out(out, y_idx, alt_idx, eps)
        gains.append((M[0] - M0) - (M[1] - M0))
        valid.append(_valid(out, gt_box, kappa).mean())
    return np.array(gains), float(np.mean(valid))


def build_exemplar_bank(records, K):
    """records: iterable of (crop_rgb, a (K,), class_id) from clean development objects.
    Keeps, per concept and class, the crop with the highest activation."""
    bank, best = {}, {}
    for crop, a, y in records:
        for k in range(K):
            key = (int(y), k)
            if a[k] > best.get(key, 0):
                best[key], bank[key] = a[k], crop
            if a[k] > best.get((-1, k), 0):
                best[(-1, k)], bank[(-1, k)] = a[k], crop
    return bank
