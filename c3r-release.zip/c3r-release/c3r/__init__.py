"""C3R: Calibrated Contrastive Concept Reasoning for auditing frozen object detectors."""
__version__ = "1.0.0"
