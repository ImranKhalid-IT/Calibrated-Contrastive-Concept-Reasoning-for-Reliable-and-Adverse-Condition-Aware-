"""Cross-detector agreement measures (Eq. 34, Table XI)."""
from __future__ import annotations

import numpy as np
from scipy.stats import spearmanr

from .interventions import sgn_dead


def sign_agreement(aie_m, aie_n, delta):
    """Eq. 34: pairs negligible in both detectors count as concordant."""
    return float(np.mean(sgn_dead(aie_m, delta) == sgn_dead(aie_n, delta)))


def concept_match_coverage(A_m, A_n, eta):
    """Fraction of concepts active in detector m (a > eta) that are also active in n,
    pooled over the valid shared objects."""
    act_m, act_n = np.asarray(A_m) > eta, np.asarray(A_n) > eta
    return float((act_m & act_n).sum() / max(act_m.sum(), 1))


def mean_spearman(abs_aie_m, abs_aie_n):
    rs = []
    for x, y in zip(abs_aie_m, abs_aie_n):
        if np.std(x) > 0 and np.std(y) > 0:
            rs.append(spearmanr(x, y).statistic)
    return float(np.mean(rs)) if rs else float("nan")


def mask_iou(m1, m2):
    inter = np.logical_and(m1, m2).sum()
    union = np.logical_or(m1, m2).sum()
    return float(inter / union) if union else float("nan")
