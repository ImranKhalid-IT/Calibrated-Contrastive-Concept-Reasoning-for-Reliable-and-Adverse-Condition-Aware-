"""Priority-ordered concept-role assignment (Eq. 26)."""
from __future__ import annotations

ROLES = ["environmental", "missing", "supporting", "conflicting", "irrelevant"]
UNDETERMINED = "undetermined"


def assign_role(ci, G_minus, miss: bool, is_env: bool, chi_spur: float,
                delta_M: float, delta_eq: float, g_0: float, gamma_env: float) -> str:
    """Return exactly one primary role (five reportable roles + undetermined).

    ci: (lo, hi) percentile interval of AIE (Eq. 27).
    The order is: environmental > missing > supporting > conflicting > irrelevant.
    Because delta_M < delta_eq, a small but consistently signed effect is reported as
    directional rather than irrelevant.
    """
    lo, hi = ci
    if is_env and chi_spur > gamma_env:
        return "environmental"
    if miss:
        return "missing"
    if lo > delta_M and G_minus >= g_0:
        return "supporting"
    if hi < -delta_M and G_minus >= g_0:
        return "conflicting"
    if lo > -delta_eq and hi < delta_eq:
        return "irrelevant"
    return UNDETERMINED


def chi_spurious(a_adv: float, a_clean: float, aie_adv: float) -> float:
    """Environmental evidence: activation introduced by the corruption that favours the
    alternative class, chi = ReLU(a^a - a^c) * ReLU(-AIE^a)."""
    return max(0.0, a_adv - a_clean) * max(0.0, -aie_adv)
