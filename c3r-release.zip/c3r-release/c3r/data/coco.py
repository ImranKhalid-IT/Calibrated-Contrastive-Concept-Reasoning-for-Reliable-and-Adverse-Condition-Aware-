"""MS COCO 2017 loading and the disjoint development / calibration / test splits (Table III)."""
from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np

from ..seeding import stream


class CocoSet:
    def __init__(self, root: str | Path, split: str, min_box_side: int = 16):
        self.root = Path(root)
        self.split = split
        with open(self.root / "annotations" / f"instances_{split}.json", encoding="utf-8") as f:
            js = json.load(f)
        self.images = {im["id"]: im for im in js["images"]}
        self.cats = {c["id"]: c for c in js["categories"]}
        self.supercat = {c["id"]: c["supercategory"] for c in js["categories"]}
        self.names = {c["id"]: c["name"] for c in js["categories"]}
        self.anns: dict[int, list] = {}
        for a in js["annotations"]:
            x, y, w, h = a["bbox"]
            if a.get("iscrowd", 0) or min(w, h) < min_box_side:
                continue
            self.anns.setdefault(a["image_id"], []).append(
                {"ann_id": a["id"], "box": [x, y, x + w, y + h], "cat": a["category_id"]})

    def image_ids_with_objects(self):
        return sorted(i for i in self.images if self.anns.get(i))

    def load(self, image_id: int):
        info = self.images[image_id]
        img = cv2.imread(str(self.root / self.split / info["file_name"]), cv2.IMREAD_COLOR)
        if img is None:
            raise FileNotFoundError(info["file_name"])
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        anns = self.anns.get(image_id, [])
        boxes = np.array([a["box"] for a in anns], float).reshape(-1, 4)
        cats = np.array([a["cat"] for a in anns], int)
        ann_ids = np.array([a["ann_id"] for a in anns], int)
        return img, boxes, cats, ann_ids


def make_splits(root, n_dev, n_cal, n_test, out_path, min_box_side=16):
    """Sample disjoint image sets: dev from train2017; calibration and test from val2017."""
    train = CocoSet(root, "train2017", min_box_side)
    val = CocoSet(root, "val2017", min_box_side)
    dev = stream("split", "dev").choice(train.image_ids_with_objects(), n_dev, replace=False)
    vids = stream("split", "val").permutation(val.image_ids_with_objects())
    cal, test = vids[:n_cal], vids[n_cal:n_cal + n_test]
    assert not set(cal) & set(test)
    splits = {"dev": sorted(map(int, dev)), "cal": sorted(map(int, cal)), "test": sorted(map(int, test))}
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(splits, f)
    return splits


def load_splits(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)
