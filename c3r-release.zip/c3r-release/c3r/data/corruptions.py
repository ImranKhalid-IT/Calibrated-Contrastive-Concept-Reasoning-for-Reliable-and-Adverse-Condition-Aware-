"""Synthetic adverse conditions (severity 0-5) and non-oracle restoration operators.

All functions take and return uint8 RGB arrays (H, W, 3). Randomness comes only from the
generator passed in, so every triplet (clean, adverse, restored) is reproducible.
Restoration operators are *not* inverses of the corruptions (Eq. 21).
"""
from __future__ import annotations

import cv2
import numpy as np

CONDITIONS = ["fog", "rain", "blur", "low_light"]


def _f(img):
    return img.astype(np.float32) / 255.0


def _u8(x):
    return np.clip(x * 255.0 + 0.5, 0, 255).astype(np.uint8)


# ----------------------------------------------------------------------------- corruptions
def fog(img, s, rng):
    if s == 0:
        return img.copy()
    x = _f(img)
    H, W = x.shape[:2]
    depth = np.linspace(1.0, 0.3, H)[:, None] * np.ones((1, W))
    noise = cv2.GaussianBlur(rng.random((H, W)).astype(np.float32), (0, 0), max(H, W) / 20)
    depth = np.clip(depth + 0.3 * (noise - noise.mean()), 0.05, 1.5)
    t = np.exp(-0.45 * s * depth)[..., None]
    A = 0.85 + 0.03 * s
    return _u8(x * t + A * (1 - t))


def rain(img, s, rng):
    if s == 0:
        return img.copy()
    x = _f(img)
    H, W = x.shape[:2]
    layer = np.zeros((H, W), np.float32)
    n = int(H * W * 0.0006 * s)
    angle = rng.uniform(-20, 20)
    length = int(8 + 4 * s)
    dx, dy = np.sin(np.deg2rad(angle)) * length, np.cos(np.deg2rad(angle)) * length
    for _ in range(n):
        x0, y0 = rng.integers(0, W), rng.integers(0, H)
        cv2.line(layer, (int(x0), int(y0)), (int(x0 + dx), int(y0 + dy)), float(rng.uniform(0.5, 1.0)), 1)
    layer = cv2.GaussianBlur(layer, (3, 3), 0)
    out = x * (1 - 0.04 * s) + 0.6 * layer[..., None]
    return _u8(out)


def _motion_kernel(length, angle):
    k = np.zeros((length, length), np.float32)
    k[length // 2, :] = 1.0
    M = cv2.getRotationMatrix2D((length / 2 - 0.5, length / 2 - 0.5), angle, 1.0)
    k = cv2.warpAffine(k, M, (length, length))
    return k / max(k.sum(), 1e-6)


def blur(img, s, rng):
    if s == 0:
        return img.copy()
    x = _f(img)
    x = cv2.GaussianBlur(x, (0, 0), 0.6 * s)
    k = _motion_kernel(int(3 * s) | 1, float(rng.uniform(0, 180)))
    return _u8(cv2.filter2D(x, -1, k))


def low_light(img, s, rng):
    if s == 0:
        return img.copy()
    x = _f(img)
    y = np.power(x, 1 + 0.35 * s) * (1 - 0.13 * s)
    y = y + rng.normal(0, 0.008 * s, y.shape).astype(np.float32)
    return _u8(y)


CORRUPT = {"fog": fog, "rain": rain, "blur": blur, "low_light": low_light}


def corrupt(img, condition, severity, rng):
    return CORRUPT[condition](img, int(severity), rng)


# ----------------------------------------------------------------------------- restoration
def _guided_filter(I, p, r=30, eps=1e-3):
    mean = lambda a: cv2.boxFilter(a, -1, (r, r))
    mI, mp = mean(I), mean(p)
    a = (mean(I * p) - mI * mp) / (mean(I * I) - mI * mI + eps)
    b = mp - a * mI
    return mean(a) * I + mean(b)


def guided_dehaze(img, omega=0.9, t0=0.25):
    x = _f(img)
    dark = cv2.erode(x.min(2), np.ones((15, 15), np.uint8))
    flat = dark.ravel()
    idx = np.argsort(flat)[-max(1, flat.size // 1000):]
    A = x.reshape(-1, 3)[idx].max(0)
    t = 1 - omega * cv2.erode((x / A).min(2), np.ones((15, 15), np.uint8))
    t = np.clip(_guided_filter(cv2.cvtColor(x, cv2.COLOR_RGB2GRAY), t.astype(np.float32)), t0, 1)
    return _u8((x - A) / t[..., None] + A)


def rain_suppression(img):
    x = cv2.medianBlur(img, 5)
    return cv2.bilateralFilter(x, 7, 40, 7)


def bounded_deblur(img, amount=1.2, sigma=2.0, max_delta=40):
    x = img.astype(np.float32)
    detail = x - cv2.GaussianBlur(x, (0, 0), sigma)
    return np.clip(x + np.clip(amount * detail, -max_delta, max_delta), 0, 255).astype(np.uint8)


def bounded_exposure(img, target=0.45, gmin=0.3, gmax=1.0):
    x = _f(img)
    m = float(np.clip(x.mean(), 1e-3, 0.999))
    g = float(np.clip(np.log(target) / np.log(m), gmin, gmax))
    return _u8(np.power(x, g))


RESTORE = {"fog": guided_dehaze, "rain": rain_suppression, "blur": bounded_deblur, "low_light": bounded_exposure}


def restore(img, condition):
    return RESTORE[condition](img)


def make_triplet(img, condition, severity, rng):
    """Eq. 21: x^a = T(x^c), x^r = R(x^a); object identity is carried by the annotation."""
    adv = corrupt(img, condition, severity, rng)
    return img, adv, restore(adv, condition)
