"""Evaluation metrics: contrastive fidelity, box agreement, role and failure F1, AUCs."""
from __future__ import annotations

import numpy as np

from .interventions import sgn_dead
from .roles import ROLES, UNDETERMINED


def method_deadzone(dev_aie: np.ndarray, dev_scores: np.ndarray, delta_M: float) -> float:
    """Eq. 41: delta^E is the rho_0-quantile of |Psi^E| on development pairs, where rho_0 is the
    fraction of development pairs that C3R declares neutral (|AIE| <= delta_M)."""
    rho0 = float(np.mean(np.abs(dev_aie) <= delta_M))
    return float(np.quantile(np.abs(dev_scores), rho0)) if rho0 > 0 else 0.0


def contrastive_fidelity(pred_scores, delta_E, audit_dir) -> tuple[float, np.ndarray]:
    """Eq. 33 with Eq. 42: CF = mean 1[sgn_{delta^E}(Psi^E) == r^audit] over V_dir."""
    pred = sgn_dead(pred_scores, delta_E)
    correct = (pred == np.asarray(audit_dir)).astype(float)
    return float(correct.mean()), correct


def box_agreement(pred_scores, delta_E, audit_iou_loss, delta_L) -> tuple[float, np.ndarray]:
    """Eq. 46-47: agreement between predicted direction and sgn_{delta_L}(Delta L^audit),
    over audited directional pairs with |Delta L^audit| > delta_L."""
    dl = np.asarray(audit_iou_loss, float)
    keep = np.abs(dl) > delta_L
    pred = sgn_dead(np.asarray(pred_scores)[keep], delta_E)
    correct = (pred == sgn_dead(dl[keep], delta_L)).astype(float)
    return (float(correct.mean()) if keep.any() else float("nan")), correct, keep


def role_report(pred_roles, audit_roles):
    """Per-role precision over assigned instances, recall over all audited instances;
    undetermined predictions count as misses (Table VI)."""
    pred, aud = np.asarray(pred_roles), np.asarray(audit_roles)
    assigned = pred != UNDETERMINED
    rows = {}
    for r in ROLES:
        tp = np.sum((pred == r) & (aud == r))
        npred = np.sum(pred == r)
        npos = np.sum(aud == r)
        P = tp / npred if npred else 0.0
        R = tp / npos if npos else 0.0
        F = 2 * P * R / (P + R) if P + R else 0.0
        rows[r] = {"n": int(npos), "P": P, "R": R, "F1": F}
    macro = {k: float(np.mean([rows[r][k] for r in ROLES])) for k in ["P", "R", "F1"]}
    return rows, macro, {"assigned": int(assigned.sum()), "withheld": int((~assigned).sum()),
                         "coverage": float(assigned.mean())}


def multilabel_report(pred: np.ndarray, gold: np.ndarray, names):
    """Per-mechanism precision/recall/F1 for multi-label failure diagnosis (Table VIII)."""
    pred, gold = np.asarray(pred, bool), np.asarray(gold, bool)
    rows = {}
    for j, n in enumerate(names):
        tp = np.sum(pred[:, j] & gold[:, j])
        P = tp / max(pred[:, j].sum(), 1)
        R = tp / max(gold[:, j].sum(), 1)
        rows[n] = {"n": int(gold[:, j].sum()), "P": P, "R": R, "F1": 2 * P * R / (P + R) if P + R else 0.0}
    macro = {k: float(np.mean([rows[n][k] for n in names])) for k in ["P", "R", "F1"]}
    return rows, macro


def curve_auc(values: np.ndarray) -> float:
    """Eq. 43: area under a deletion/insertion curve sampled at equally spaced fractions."""
    v = np.asarray(values, float)
    x = np.linspace(0, 1, len(v))
    return float(np.sum((v[1:] + v[:-1]) * np.diff(x)) / 2)


def concept_score_from_saliency(S_contrast: np.ndarray, concept_mask: np.ndarray,
                                ctrl_masks: list, eps: float = 1e-6) -> float:
    """Eq. 39: Psi^E = (mean S over Omega_gk - mean over matched controls) / (sd_box(S) + eps).
    S_contrast is the contrastive saliency (Eq. 36) cropped to the matched box."""
    m = S_contrast[concept_mask].mean() if concept_mask.any() else 0.0
    c = np.mean([S_contrast[cm].mean() for cm in ctrl_masks if cm.any()]) if ctrl_masks else 0.0
    return float((m - c) / (S_contrast.std() + eps))


def concept_mask(act_map: np.ndarray, q: float) -> np.ndarray:
    """Eq. 37: Omega_gk = top-q fraction of the upsampled concept activation map in the box."""
    if act_map.max() <= 0:
        return np.zeros_like(act_map, bool)
    return act_map >= np.quantile(act_map, 1 - q)


def matched_control_masks(mask: np.ndarray, n: int, rng, max_regions: int = 5) -> list:
    """Random rectangular regions inside the box with the same area as the concept mask
    (matched-area spatial controls)."""
    H, W = mask.shape
    area = int(mask.sum())
    out = []
    if area == 0:
        return out
    for _ in range(n):
        ar = rng.uniform(0.5, 2.0)
        h = int(np.clip(round(np.sqrt(area * ar)), 1, H))
        w = int(np.clip(round(area / h), 1, W))
        y0, x0 = rng.integers(0, H - h + 1), rng.integers(0, W - w + 1)
        m = np.zeros_like(mask)
        m[y0:y0 + h, x0:x0 + w] = True
        out.append(m)
    return out
