"""Frozen Hugging Face DETR-ResNet-50 with object-query head re-evaluation.

The native feature z is the final decoder hidden state of the matched object query; the frozen
class and box heads are re-applied to edited z for that same query.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn.functional as F

from .base import COCO80, Detections, FrozenDetector


@dataclass
class QueryHandle:
    query: int
    orig_hw: tuple


class DETRDetector(FrozenDetector):
    name = "detr"
    interfaces = ["detr"]

    def __init__(self, cfg, device="cuda"):
        from transformers import DetrForObjectDetection, DetrImageProcessor

        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.proc = DetrImageProcessor.from_pretrained(
            cfg.hf_name, size={"shortest_edge": cfg.imgsz, "longest_edge": cfg.imgsz})
        self.model = DetrForObjectDetection.from_pretrained(cfg.hf_name).eval().to(self.device)
        for p in self.model.parameters():
            p.requires_grad_(False)
        self.idx = torch.tensor(COCO80, device=self.device)   # DETR label ids are COCO category ids
        self.score_threshold = 0.5

    def _hidden(self, imgs):
        enc = self.proc(images=list(imgs), return_tensors="pt").to(self.device)
        out = self.model(**enc)
        return out.last_hidden_state                       # (B, 100, 256)

    def _heads(self, h, hw):
        logits = self.model.class_labels_classifier(h)     # (..., 92), last = no-object
        p = F.softmax(logits, -1)
        fg = (1 - p[..., -1]).clamp_min(1e-12)
        probs = p[..., self.idx] / fg[..., None]
        cxcywh = self.model.bbox_predictor(h).sigmoid()
        H, W = hw
        cx, cy, w, hh = cxcywh.unbind(-1)
        box = torch.stack([(cx - w / 2) * W, (cy - hh / 2) * H, (cx + w / 2) * W, (cy + hh / 2) * H], -1)
        return probs, fg, box, p

    @torch.no_grad()
    def detect(self, img):
        h = self._hidden([img])[0]
        probs, fg, box, p = self._heads(h, img.shape[:2])
        cls_p = p[:, :-1]
        scores, labels = cls_p.max(-1)
        keep = torch.where(scores >= self.score_threshold)[0].tolist()
        if not keep:
            return Detections(np.zeros((0, 4)), np.zeros(0), np.zeros(0, int), np.zeros((0, 80)), np.zeros(0),
                              np.zeros((0, 256)))
        return Detections(box[keep].cpu().numpy(), scores[keep].cpu().numpy(), labels[keep].cpu().numpy(),
                          probs[keep].cpu().numpy(), fg[keep].cpu().numpy(), h[keep].cpu().numpy(),
                          [QueryHandle(q, img.shape[:2]) for q in keep], [self.name] * len(keep))

    @torch.no_grad()
    def head(self, handle: QueryHandle, Z):
        z = torch.as_tensor(np.asarray(Z), dtype=torch.float32, device=self.device)
        probs, fg, box, _ = self._heads(z, handle.orig_hw)
        return {"probs": probs.cpu().numpy(), "obj": fg.cpu().numpy(), "box": box.cpu().numpy()}

    @torch.no_grad()
    def features_at(self, imgs, handle: QueryHandle, batch: int = 8):
        Zs, outs = [], {"probs": [], "obj": [], "box": []}
        for s in range(0, len(imgs), batch):
            h = self._hidden(imgs[s:s + batch])[:, handle.query]
            probs, fg, box, _ = self._heads(h, handle.orig_hw)
            Zs.append(h.cpu().numpy())
            outs["probs"].append(probs.cpu().numpy()); outs["obj"].append(fg.cpu().numpy())
            outs["box"].append(box.cpu().numpy())
        return np.concatenate(Zs), {k: np.concatenate(v) for k, v in outs.items()}
