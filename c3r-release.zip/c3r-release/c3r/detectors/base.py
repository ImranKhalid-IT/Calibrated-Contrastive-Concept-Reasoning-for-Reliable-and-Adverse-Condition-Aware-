"""Common interface for frozen detectors (Eq. 1).

Every wrapper exposes
  detect(img)                      -> Detections (boxes in original pixel coordinates)
  head(handle, Z)                  -> dict(probs[B,C], obj[B], box[B,4]); re-evaluates the frozen
                                      head at the *same* candidate for edited native features
  features_at(imgs, handle)        -> (Z[B,d], out dict) for images edited in pixel space, evaluated
                                      at the same candidate identity (proposal / grid cell / query)
Class distributions are over `class_ids` (80 COCO category ids) and conditional on foreground.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

COCO80 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 28,
          31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55,
          56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 67, 70, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 84,
          85, 86, 87, 88, 89, 90]
CLASS_INDEX = {c: i for i, c in enumerate(COCO80)}


@dataclass
class Detections:
    boxes: np.ndarray            # (N,4) xyxy, original image coordinates
    scores: np.ndarray           # (N,)
    labels: np.ndarray           # (N,) COCO category ids
    probs: np.ndarray            # (N,80) conditional class distribution
    obj: np.ndarray              # (N,) foreground / objectness score
    feats: np.ndarray            # (N,d) native features z (for YOLO d differs by level: see iface)
    handles: list = field(default_factory=list)
    iface: list = field(default_factory=list)   # interface key per candidate


class FrozenDetector:
    name = "base"
    interfaces: list[str] = []

    def detect(self, img: np.ndarray) -> Detections:
        raise NotImplementedError

    def head(self, handle, Z: np.ndarray) -> dict:
        raise NotImplementedError

    def features_at(self, imgs: list, handle) -> tuple[np.ndarray, dict]:
        raise NotImplementedError

    def prepare(self, img: np.ndarray) -> None:
        """Called once per image before head(); detectors that need cached context override it."""

    def head_fn(self, handle):
        return lambda Z: self.head(handle, Z)


def build_detector(name: str, cfg, device: str = "cuda") -> FrozenDetector:
    if name == "faster_rcnn":
        from .faster_rcnn import FasterRCNNDetector
        return FasterRCNNDetector(cfg.faster_rcnn, device)
    if name == "yolov8m":
        from .yolov8 import YOLOv8Detector
        return YOLOv8Detector(cfg.yolov8m, device)
    if name == "detr":
        from .detr import DETRDetector
        return DETRDetector(cfg.detr, device)
    raise ValueError(name)
