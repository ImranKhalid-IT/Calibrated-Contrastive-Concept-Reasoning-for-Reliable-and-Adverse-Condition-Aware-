"""Frozen torchvision Faster R-CNN ResNet-50 FPN (COCO V1) with fixed-RoI head re-evaluation.

The native feature z is the 1024-d TwoMLPHead output for the RoI equal to the final detection
box. Head re-evaluation applies the frozen box predictor to edited z at that same RoI.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import torch
import torch.nn.functional as F
import torchvision
from torchvision.models.detection import FasterRCNN_ResNet50_FPN_Weights

from .base import CLASS_INDEX, COCO80, Detections, FrozenDetector

_IDX91 = torch.tensor(COCO80)  # positions of the 80 used ids inside the 91-way torchvision head


@dataclass
class RoIHandle:
    roi: torch.Tensor        # (1,4) RoI in transformed coordinates
    ratio: tuple             # (ry, rx) transformed / original
    image_size: tuple        # transformed (h, w)
    label: int               # COCO id of the clean prediction (box branch used for decoding)


class FasterRCNNDetector(FrozenDetector):
    name = "faster_rcnn"
    interfaces = ["faster_rcnn"]

    def __init__(self, cfg, device="cuda"):
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        m = torchvision.models.detection.fasterrcnn_resnet50_fpn(
            weights=FasterRCNN_ResNet50_FPN_Weights.COCO_V1,
            min_size=cfg.min_size, max_size=cfg.max_size,
            rpn_nms_thresh=cfg.rpn_nms, box_nms_thresh=cfg.box_nms,
            box_detections_per_img=cfg.max_dets, box_score_thresh=0.0)
        self.model = m.eval().to(self.device)
        for p in self.model.parameters():
            p.requires_grad_(False)
        self.score_threshold = 0.5

    # ------------------------------------------------------------------ internals
    def _prep(self, imgs, requires_grad=False):
        ts = [torch.from_numpy(np.ascontiguousarray(i)).permute(2, 0, 1).float().div(255).to(self.device)
              for i in imgs]
        il, _ = self.model.transform(ts)
        if requires_grad:
            il.tensors.requires_grad_(True)
        return il, [t.shape[-2:] for t in ts]

    def _head_out(self, z, roi, image_size, label):
        rh = self.model.roi_heads
        logits, reg = rh.box_predictor(z)
        p91 = F.softmax(logits, -1)
        fg = (1 - p91[:, 0]).clamp_min(1e-12)
        probs = p91[:, _IDX91.to(z.device)] / fg[:, None]
        b = rh.box_coder.decode(reg, [roi.expand(len(z), 4)]).reshape(len(z), -1, 4)[:, label]
        boxes = torch.stack([b[:, 0].clamp(0, image_size[1]), b[:, 1].clamp(0, image_size[0]),
                             b[:, 2].clamp(0, image_size[1]), b[:, 3].clamp(0, image_size[0])], 1)
        return probs, fg, boxes, logits

    def _to_orig(self, boxes, ratio):
        ry, rx = ratio
        return boxes / torch.tensor([rx, ry, rx, ry], device=boxes.device)

    def _feats(self, features, rois, image_sizes):
        rh = self.model.roi_heads
        return rh.box_head(rh.box_roi_pool(features, rois, image_sizes))

    # ------------------------------------------------------------------ public API
    @torch.no_grad()
    def detect(self, img):
        il, orig = self._prep([img])
        feats = self.model.backbone(il.tensors)
        props, _ = self.model.rpn(il, feats)
        dets, _ = self.model.roi_heads(feats, props, il.image_sizes)
        d = dets[0]
        keep = d["scores"] >= self.score_threshold
        boxes_t, labels = d["boxes"][keep], d["labels"][keep]
        ratio = (il.image_sizes[0][0] / orig[0][0], il.image_sizes[0][1] / orig[0][1])
        if len(boxes_t) == 0:
            return Detections(np.zeros((0, 4)), np.zeros(0), np.zeros(0, int), np.zeros((0, 80)),
                              np.zeros(0), np.zeros((0, 1024)))
        z = self._feats(feats, [boxes_t], il.image_sizes)
        handles, P, O, B = [], [], [], []
        for j in range(len(boxes_t)):
            h = RoIHandle(boxes_t[j:j + 1], ratio, tuple(il.image_sizes[0]), int(labels[j]))
            p, o, b, _ = self._head_out(z[j:j + 1], h.roi, h.image_size, h.label)
            handles.append(h)
            P.append(p[0].cpu().numpy()); O.append(float(o[0])); B.append(self._to_orig(b, ratio)[0].cpu().numpy())
        return Detections(np.array(B), d["scores"][keep].cpu().numpy(), labels.cpu().numpy(), np.array(P),
                          np.array(O), z.cpu().numpy(), handles, [self.name] * len(handles))

    @torch.no_grad()
    def head(self, handle: RoIHandle, Z):
        z = torch.as_tensor(np.asarray(Z), dtype=torch.float32, device=self.device)
        p, o, b, _ = self._head_out(z, handle.roi, handle.image_size, handle.label)
        return {"probs": p.cpu().numpy(), "obj": o.cpu().numpy(), "box": self._to_orig(b, handle.ratio).cpu().numpy()}

    @torch.no_grad()
    def features_at(self, imgs, handle: RoIHandle, batch: int = 8):
        Zs, outs = [], {"probs": [], "obj": [], "box": []}
        for s in range(0, len(imgs), batch):
            il, _ = self._prep(imgs[s:s + batch])
            feats = self.model.backbone(il.tensors)
            rois = [handle.roi] * len(il.image_sizes)
            z = self._feats(feats, rois, il.image_sizes)
            p, o, b, _ = self._head_out(z, handle.roi, handle.image_size, handle.label)
            Zs.append(z.cpu().numpy())
            outs["probs"].append(p.cpu().numpy()); outs["obj"].append(o.cpu().numpy())
            outs["box"].append(self._to_orig(b, handle.ratio).cpu().numpy())
        return np.concatenate(Zs), {k: np.concatenate(v) for k, v in outs.items()}

    # ------------------------------------------------------------------ gradients (Grad-CAM++)
    def level_for(self, handle: RoIHandle) -> str:
        x1, y1, x2, y2 = handle.roi[0].tolist()
        k = math.floor(4 + math.log2(math.sqrt(max((x2 - x1) * (y2 - y1), 1e-6)) / 224 + 1e-8))
        return str(min(max(k, 2), 5) - 2)

    def logits_and_activation(self, img, handle: RoIHandle):
        """Differentiable 91-way logits at the fixed RoI and the FPN activation of the RoI's
        pyramid level (retain_grad enabled). Used by Grad-CAM++ and Score-CAM."""
        il, _ = self._prep([img], requires_grad=True)
        feats = self.model.backbone(il.tensors)
        lvl = self.level_for(handle)
        act = feats[lvl]
        act.retain_grad()
        z = self._feats(feats, [handle.roi], il.image_sizes)
        _, _, _, logits = self._head_out(z, handle.roi, handle.image_size, handle.label)
        return logits[0], act, il

    @staticmethod
    def idx91(coco_id: int) -> int:
        return int(coco_id)  # torchvision uses COCO category ids directly as the 91-way index

    @staticmethod
    def idx80(coco_id: int) -> int:
        return CLASS_INDEX[int(coco_id)]
