"""Frozen Ultralytics YOLOv8m with grid-cell head re-evaluation.

The native feature z is the neck feature vector at the grid cell (pyramid level P3/P4/P5) of the
matched anchor. Head re-evaluation writes the edited vector back into that cell and re-runs the
frozen Detect head; the output is read at the same anchor index. Each pyramid level is a separate
adapter interface because channel widths differ (192 / 384 / 576 for YOLOv8m).
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np
import torch
import torchvision

from .base import COCO80, Detections, FrozenDetector

LEVELS = ["P3", "P4", "P5"]


@dataclass
class CellHandle:
    level: int
    cy: int
    cx: int
    anchor: int
    ratio: float
    pad: tuple          # (left, top)
    orig_hw: tuple


class YOLOv8Detector(FrozenDetector):
    name = "yolov8m"
    interfaces = [f"yolov8m/{l}" for l in LEVELS]

    def __init__(self, cfg, device="cuda"):
        from ultralytics import YOLO

        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.model = YOLO(cfg.weights).model.eval().to(self.device)
        for p in self.model.parameters():
            p.requires_grad_(False)
        self.detect_head = self.model.model[-1]
        self.imgsz = cfg.imgsz
        self.nms_iou = cfg.nms_iou
        self.max_dets = cfg.max_dets
        self.score_threshold = 0.5
        self._feats = None
        self.detect_head.register_forward_pre_hook(self._hook)

    def _hook(self, module, inputs):
        self._feats = [t.detach().clone() for t in inputs[0]]

    # ------------------------------------------------------------------ preprocessing
    def _letterbox(self, img):
        h, w = img.shape[:2]
        r = self.imgsz / max(h, w)
        nh, nw = int(round(h * r)), int(round(w * r))
        top, left = (self.imgsz - nh) // 2, (self.imgsz - nw) // 2
        canvas = np.full((self.imgsz, self.imgsz, 3), 114, np.uint8)
        canvas[top:top + nh, left:left + nw] = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
        t = torch.from_numpy(canvas).permute(2, 0, 1).float().div(255)
        return t, r, (left, top)

    def _run(self, imgs):
        ts, meta = [], []
        for im in imgs:
            t, r, pad = self._letterbox(im)
            ts.append(t)
            meta.append((r, pad))
        y = self.model(torch.stack(ts).to(self.device))
        y = y[0] if isinstance(y, (list, tuple)) else y
        return y, [f.clone() for f in self._feats], meta

    def _grid_shapes(self, feats):
        return [(f.shape[2], f.shape[3]) for f in feats]

    def _anchor_to_cell(self, a, shapes):
        off = 0
        for l, (h, w) in enumerate(shapes):
            if a < off + h * w:
                r = a - off
                return l, r // w, r % w
            off += h * w
        raise IndexError(a)

    @staticmethod
    def _decode(y_a, r, pad, hw):
        cx, cy, w, h = y_a[:4]
        box = np.array([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2])
        box[[0, 2]] = np.clip((box[[0, 2]] - pad[0]) / r, 0, hw[1])
        box[[1, 3]] = np.clip((box[[1, 3]] - pad[1]) / r, 0, hw[0])
        return box

    def _out_at(self, y, anchor, r, pad, hw):
        y = y.detach().cpu().numpy()            # (B, 4+80, A)
        cls = y[:, 4:, anchor]
        probs = cls / np.clip(cls.sum(1, keepdims=True), 1e-12, None)
        boxes = np.stack([self._decode(y[b, :, anchor], r, pad, hw) for b in range(len(y))])
        return {"probs": probs, "obj": cls.max(1), "box": boxes}

    # ------------------------------------------------------------------ public API
    @torch.no_grad()
    def detect(self, img):
        y, feats, meta = self._run([img])
        r, pad = meta[0]
        hw = img.shape[:2]
        pred = y[0]                              # (84, A)
        scores, cls = pred[4:].max(0)
        keep = torch.where(scores >= self.score_threshold)[0]
        xywh = pred[:4, keep].T
        xyxy = torch.cat([xywh[:, :2] - xywh[:, 2:] / 2, xywh[:, :2] + xywh[:, 2:] / 2], 1)
        k2 = torchvision.ops.batched_nms(xyxy, scores[keep], cls[keep], self.nms_iou)[: self.max_dets]
        anchors = keep[k2].tolist()
        shapes = self._grid_shapes(feats)
        B, S, L, P, O, Z, H, I = [], [], [], [], [], [], [], []
        for a in anchors:
            lvl, cy, cx = self._anchor_to_cell(a, shapes)
            h = CellHandle(lvl, cy, cx, a, r, pad, hw)
            o = self._out_at(y[:1], a, r, pad, hw)
            B.append(o["box"][0]); P.append(o["probs"][0]); O.append(o["obj"][0])
            S.append(float(scores[a])); L.append(COCO80[int(cls[a])])
            Z.append(feats[lvl][0, :, cy, cx].cpu().numpy()); H.append(h); I.append(self.interfaces[lvl])
        if not anchors:
            return Detections(np.zeros((0, 4)), np.zeros(0), np.zeros(0, int), np.zeros((0, 80)), np.zeros(0), [])
        return Detections(np.array(B), np.array(S), np.array(L), np.array(P), np.array(O), Z, H, I)

    @torch.no_grad()
    def head(self, handle: CellHandle, Z, chunk: int = 16):
        Z = torch.as_tensor(np.asarray(Z), dtype=torch.float32, device=self.device)
        base = self._base_feats(handle)
        outs = {"probs": [], "obj": [], "box": []}
        for s in range(0, len(Z), chunk):
            zc = Z[s:s + chunk]
            feats = [f.expand(len(zc), -1, -1, -1).clone() for f in base]
            feats[handle.level][:, :, handle.cy, handle.cx] = zc
            y = self.detect_head(feats)
            y = y[0] if isinstance(y, (list, tuple)) else y
            o = self._out_at(y, handle.anchor, handle.ratio, handle.pad, handle.orig_hw)
            for k in outs:
                outs[k].append(o[k])
        return {k: np.concatenate(v) for k, v in outs.items()}

    def prepare(self, img):
        """Cache clean neck features of the current image (must be called before head())."""
        with torch.no_grad():
            _, feats, _ = self._run([img])
        self._cached = feats

    def _base_feats(self, handle):
        return self._cached

    @torch.no_grad()
    def features_at(self, imgs, handle: CellHandle, batch: int = 8):
        Zs, outs = [], {"probs": [], "obj": [], "box": []}
        for s in range(0, len(imgs), batch):
            y, feats, _ = self._run(imgs[s:s + batch])
            Zs.append(feats[handle.level][:, :, handle.cy, handle.cx].cpu().numpy())
            o = self._out_at(y, handle.anchor, handle.ratio, handle.pad, handle.orig_hw)
            for k in outs:
                outs[k].append(o[k])
        return np.concatenate(Zs), {k: np.concatenate(v) for k, v in outs.items()}
