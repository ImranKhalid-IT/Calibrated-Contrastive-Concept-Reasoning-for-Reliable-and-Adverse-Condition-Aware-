"""Two-stage explanation-reliability calibration (Eq. 31) and selective reporting (Eq. 32)."""
from __future__ import annotations

import numpy as np
from scipy.optimize import minimize
from sklearn.metrics import roc_auc_score

FEATURE_NAMES = ["abs_aie", "ci_width", "G", "var_rep", "valid", "rec_M", "rec_L", "iota"]


def features(abs_aie, ci_width, G, var_rep, valid, rec_M, rec_L, has_rec) -> np.ndarray:
    """phi_gk = (|AIE|, u-l, G, Var, v, iota*Rec_M, iota*Rec_L, iota)."""
    iota = np.asarray(has_rec, float)
    return np.column_stack([abs_aie, ci_width, G, var_rep, valid,
                            iota * np.nan_to_num(rec_M), iota * np.nan_to_num(rec_L), iota])


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -50, 50)))


def _bce(y, p):
    p = np.clip(p, 1e-12, 1 - 1e-12)
    return -(y * np.log(p) + (1 - y) * np.log(1 - p))


class ReliabilityCalibrator:
    """Stage 1: l2-regularised logistic score on development pairs.
    Stage 2: Platt map q = sigma(a s + c), a > 0, on calibration pairs with the score fixed."""

    def __init__(self, lambda_w: float = 1.0):
        self.lambda_w = lambda_w
        self.mu = self.sd = self.w = None
        self.b = 0.0
        self.a, self.c = 1.0, 0.0

    def fit_score(self, X, y):
        X, y = np.asarray(X, float), np.asarray(y, float)
        self.mu, self.sd = X.mean(0), X.std(0) + 1e-8
        Xs = (X - self.mu) / self.sd

        def f(theta):
            w, b = theta[:-1], theta[-1]
            p = _sigmoid(Xs @ w + b)
            loss = _bce(y, p).sum() + self.lambda_w * w @ w
            g = Xs.T @ (p - y) + 2 * self.lambda_w * w
            return loss, np.concatenate([g, [np.sum(p - y)]])

        res = minimize(f, np.zeros(X.shape[1] + 1), jac=True, method="L-BFGS-B")
        self.w, self.b = res.x[:-1], res.x[-1]
        return self

    def score(self, X):
        return ((np.asarray(X, float) - self.mu) / self.sd) @ self.w + self.b

    def fit_platt(self, X, y):
        s, y = self.score(X), np.asarray(y, float)

        def f(theta):
            la, c = theta                     # a = exp(la) > 0 enforces monotonicity
            p = _sigmoid(np.exp(la) * s + c)
            return _bce(y, p).sum()

        res = minimize(f, np.zeros(2), method="Nelder-Mead", options={"xatol": 1e-8, "fatol": 1e-10})
        self.a, self.c = float(np.exp(res.x[0])), float(res.x[1])
        return self

    def predict_uncalibrated(self, X):
        return _sigmoid(self.score(X))

    def predict(self, X):
        return _sigmoid(self.a * self.score(X) + self.c)


def ece(y, p, n_bins: int = 10) -> float:
    y, p = np.asarray(y, float), np.asarray(p, float)
    edges = np.linspace(0, 1, n_bins + 1)
    idx = np.clip(np.digitize(p, edges[1:-1]), 0, n_bins - 1)
    return float(sum(np.abs(y[idx == b].mean() - p[idx == b].mean()) * np.mean(idx == b)
                     for b in range(n_bins) if np.any(idx == b)))


def brier(y, p) -> float:
    return float(np.mean((np.asarray(p) - np.asarray(y)) ** 2))


def nll(y, p) -> float:
    return float(np.mean(_bce(np.asarray(y, float), np.asarray(p, float))))


def auroc(y, p) -> float:
    y = np.asarray(y)
    return float(roc_auc_score(y, p)) if 0 < y.mean() < 1 else float("nan")


def risk_at_coverage(y, q, coverage: float):
    """Retain the top `coverage` fraction ranked by q; risk = mean disagreement."""
    y, q = np.asarray(y, float), np.asarray(q, float)
    n = int(round(coverage * len(q)))
    keep = np.argsort(-q, kind="stable")[:n]
    return (float(1 - y[keep].mean()) if n else float("nan")), n


def select_thresholds(y_cal, q_cal, target_report: float, target_uncertain: float):
    """Smallest tau_H whose retained set has risk <= target_report, and smallest tau_L
    whose retained set has risk <= target_uncertain (calibration split only)."""
    y, q = np.asarray(y_cal, float), np.asarray(q_cal, float)
    grid = np.unique(np.round(q, 2))

    def first_ok(target):
        for t in grid:
            sel = q >= t
            if sel.any() and 1 - y[sel].mean() <= target:
                return float(t)
        return float(grid[-1])

    tau_H = first_ok(target_report)
    tau_L = min(first_ok(target_uncertain), tau_H)
    return tau_L, tau_H


def tri_zone(q, tau_L: float, tau_H: float) -> np.ndarray:
    q = np.asarray(q)
    return np.where(q >= tau_H, "REPORT", np.where(q >= tau_L, "UNCERTAIN", "ABSTAIN"))


def zone_summary(y, q, tau_L, tau_H, n_total: int):
    z = tri_zone(q, tau_L, tau_H)
    y = np.asarray(y, float)
    out = {}
    for name in ["REPORT", "UNCERTAIN", "ABSTAIN"]:
        m = z == name
        out[name] = {"n": int(m.sum()), "cond_cov": float(m.mean()), "overall_cov": float(m.sum() / n_total),
                     "risk": float(1 - y[m].mean()) if m.any() else float("nan")}
    return out
