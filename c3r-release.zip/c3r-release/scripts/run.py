#!/usr/bin/env python
"""Command-line entry point.

Examples
  python scripts/run.py splits
  python scripts/run.py explain --split test
  python scripts/run.py explain --split test --ablation no_controls
  python scripts/run.py evaluate
  python scripts/run.py explain --split test -o intervention.n_controls=20   # config override
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from c3r.config import load_config, save_config  # noqa: E402
from c3r.pipeline import out_dir, run_stage  # noqa: E402

STAGES = ["splits", "robustness", "extract", "concepts", "explain", "baselines", "adverse", "cross", "evaluate"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("stage", choices=STAGES)
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--split", default="test", choices=["dev", "cal", "test"])
    ap.add_argument("--ablation", default="full")
    ap.add_argument("--max-images", type=int, default=None, help="cross stage: limit images (smoke tests)")
    ap.add_argument("-o", "--override", action="append", default=[], help="dotted.key=value")
    a = ap.parse_args()
    cfg = load_config(a.config, a.override)
    save_config(cfg, out_dir(cfg) / "config_used.yaml")
    kw = {}
    if a.stage == "explain":
        kw = {"split": a.split, "ablation": a.ablation}
    elif a.stage == "baselines":
        kw = {"split": a.split}
    elif a.stage == "concepts":
        kw = {"ablation": a.ablation}
    elif a.stage == "cross":
        kw = {"max_images": a.max_images}
    run_stage(cfg, a.stage, **kw)


if __name__ == "__main__":
    main()
