#!/usr/bin/env bash
# Full C3R reproduction. Each stage writes to outputs/ and can be re-run on its own.
set -euo pipefail
cd "$(dirname "$0")/.."
PY="python scripts/run.py"
CFG="${CFG:-configs/default.yaml}"

$PY splits      --config "$CFG"
$PY robustness  --config "$CFG"                     # Fig. 4
$PY extract     --config "$CFG"
$PY concepts    --config "$CFG"
$PY concepts    --config "$CFG" --ablation no_alignment

for S in dev cal test; do                           # dev -> score, cal -> Platt + thresholds, test -> sealed
  $PY explain --config "$CFG" --split $S
done
$PY baselines --config "$CFG" --split dev           # dead-zones delta^E
$PY baselines --config "$CFG" --split test          # Table IV
$PY adverse   --config "$CFG"                       # Tables VII, VIII
$PY cross     --config "$CFG"                       # Table XI

for AB in no_alignment top2_competitor no_controls no_missing no_localization no_adverse \
          no_image_validation no_calibration no_abstention; do
  for S in dev cal test; do
    $PY explain --config "$CFG" --split $S --ablation $AB
  done
done

$PY evaluate --config "$CFG"                        # Tables IV-XI -> outputs/tables/
