# C³R: Calibrated Contrastive Concept Reasoning

Reference implementation of **C³R**, a post-hoc framework for auditing frozen object detectors
(Faster R-CNN ResNet-50 FPN, YOLOv8m, DETR-ResNet-50) under adverse visual conditions.

C³R treats a detector explanation as a testable claim. For every matched object it:

- fixes a plausible alternative class;
- estimates control-adjusted, dose-integrated concept effects in a cross-detector concept space;
- verifies expected-but-missing evidence by bounded insertion;
- traces clean–adverse–restored behaviour;
- reports, flags or withholds each concept-role claim with an independently audited reliability
  calibrator.

> **Status.** The package is complete and every stage runs end to end. The detector-independent
> parts are covered by the unit and integration tests in `tests/`. Absolute numbers depend on your
> hardware and on library versions. After a full run, take the reported tables from
> `outputs/tables/`.

---

## 1. Installation

```bash
conda create -n c3r python=3.10.12 -y && conda activate c3r
pip install -r requirements.txt
python -m pytest -q tests            # 21 tests, CPU only, < 5 s
```

Reference environment (Table III): Google Colab, NVIDIA Tesla T4 (16 GB), CUDA 12.1, cuDNN 8.9.2,
PyTorch 2.3.1, Torchvision 0.18.1, Ultralytics 8.2.103, Transformers 4.41.2.

## 2. Data

Download MS COCO 2017 into `data/coco/`:

```
data/coco/train2017/  data/coco/val2017/
data/coco/annotations/instances_train2017.json
data/coco/annotations/instances_val2017.json
```

Detector weights download automatically on first use:

- `fasterrcnn_resnet50_fpn_coco-258fb6c6.pth` (Torchvision)
- `yolov8m.pt` (Ultralytics)
- `facebook/detr-resnet-50` (Hugging Face)

## 3. Reproducing the paper

```bash
bash scripts/run_all.sh          # all stages, all ablations, then all tables
```

You can also run each stage on its own (`python scripts/run.py <stage> [--split dev|cal|test] [--ablation NAME]`):

| Stage | What it produces | Paper |
|---|---|---|
| `splits` | disjoint 2,000 dev (train2017) / 500 cal / 500 test (val2017) image ids, seed 42 | Table III |
| `robustness` | thresholded COCO AP@[.50:.95] for severities 0–5 | Fig. 4 |
| `extract` | matched clean + corrupted dev features for all detectors | §III-C |
| `concepts` | adapters, shared dictionary (K = 20), priors, K_env, exemplars, CRAFT baseline | Eqs. 3–8 |
| `explain` | main + audit explanation of sampled object–concept instances | Tables V, VI, IX |
| `baselines` | Grad-CAM++, D-RISE, Score-CAM, CRAFT concept scores; deletion/insertion AUC | Table IV |
| `adverse` | clean–adverse–restored triplets, recovery, failure diagnosis | Tables VII, VIII |
| `cross` | cross-detector coverage, Spearman, sign agreement, mask IoU, latency, VRAM | Table XI |
| `evaluate` | every table as CSV and LaTeX in `outputs/tables/` | Tables IV–XI |

Order matters: `explain` must run on `dev`, `cal` and `test` before `baselines`, `evaluate` and
the ablations. Ablation runs reuse the audit labels of the full configuration, so all
configurations are scored against the same audit.

**Overrides:** any configuration value can be changed from the command line, for example a quick
smoke test:

```bash
python scripts/run.py explain --split test -o roles.n_audit_instances=50 -o intervention.n_controls=20
```

**Runtime:** D-RISE with 1,000 masks per object dominates the cost. Lower
`baselines.drise_masks` for quick checks.

## 4. Leakage safeguards

- Class priors, the confusion matrix, K_env, the CRAFT dictionary, the method dead-zones and the
  stage-1 reliability score use **development** data only.
- The Platt map and the reporting thresholds τ_L and τ_H use the **calibration** split only. Set
  them in the config to freeze the manuscript values, or leave them `null` to re-select them on
  the calibration split.
- The **test** split is used only for evaluation.
- Every random draw comes from a named seed stream derived from the base seed 42
  (`c3r/seeding.py`). Audit streams (`"audit", …`) are disjoint from role-assignment and
  calibrator streams (`"main", …`), which implements Eq. 29.

## 5. Equation → code map

| Manuscript | Code |
|---|---|
| Eq. 1 frozen output, head re-evaluation | `c3r/detectors/{faster_rcnn,yolov8,detr}.py` |
| Eq. 2 one-to-one matching | `c3r/matching.py::match_objects` |
| Eqs. 3–7 embedding, InfoNCE, sparse coding, joint objective | `c3r/concepts/alignment.py`, `sparse_coding.py` |
| Eq. 8 class priors | `c3r/concepts/priors.py` |
| Eqs. 9–10 fixed alternative, log-margin | `c3r/contrast.py` |
| Eqs. 11–15 suppression, native edit, raw/controlled effect, AIE, agreement G | `c3r/interventions.py`, `c3r/image_edits.py` |
| Eqs. 16–20 deficit, bounded insertion, gain, decision, coupled response | `c3r/interventions.py` |
| Eqs. 21–25 triplets, recovery, failure vector | `c3r/data/corruptions.py`, `c3r/adverse.py` |
| Eq. 26 role assignment | `c3r/roles.py` |
| Eq. 27 object-level CI | `c3r/interventions.py::removal_intervention` |
| Eqs. 28–32 audit, two-stage calibration, selective policy | `c3r/explain.py`, `c3r/calibration.py` |
| Eq. 34 cross-detector sign agreement | `c3r/cross_detector.py` |
| Eq. 35 image-clustered paired bootstrap, Holm | `c3r/stats.py` |
| Eqs. 36–42 baseline mapping, CRAFT matching, dead-zones | `c3r/baselines/`, `c3r/metrics.py` |
| Eq. 43 deletion/insertion AUC, Eq. 44 C³R ranking map | `c3r/baselines/del_ins.py` |
| Eqs. 45–47 box agreement | `c3r/metrics.py::box_agreement` |

### Implementation choices

The manuscript describes these points only in words. The code makes them explicit; each is
documented in the module docstring:

1. **Faster R-CNN** is re-evaluated at a fixed RoI equal to the final detection box. YOLOv8m is
   re-evaluated at its anchor grid cell, with one adapter interface per pyramid level. DETR is
   re-evaluated at its object query.
2. **Nonsemantic feature-space controls** are energy-matched random directions orthogonal to the
   decoded concept subspace span(B_m D).
3. **Concept activation maps** are built by grid occlusion inside the matched box.
4. **Image-space edits:**
   - Removal blends the concept mask with a blurred copy; its matched controls blur equal-area
     regions.
   - Insertion pastes a development exemplar; its control pastes a phase-scrambled version of the
     same exemplar.
5. **Failure mechanisms:**
   - The five mechanism scores follow the definitions in §III-E.
   - Audit labels come from the independent audit-stream re-execution.
   - A case counts as *recovered* when its recovery ratio is ≥ 0.5.
6. **Environmental concepts (K_env)** are concepts whose development activation rises by more
   than 0.5 clean standard deviations under corruption.

## 6. Outputs

`outputs/` contains:

- one `.pkl` file of per-instance results per stage;
- `config_used.yaml`;
- `tables/*.csv` and `tables/*.tex`.

Every number in the tables can be traced back to per-instance records.

## 7. License

MIT (see `LICENSE`).
