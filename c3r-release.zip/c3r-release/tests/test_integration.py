"""End-to-end test of the explainer, image edits and table assembly with a fake detector.

The fake detector computes native features from mean colours of a 4x4 grid inside a fixed RoI
and applies a linear head, so the whole C3R path (matching, concept maps, controlled feature and
image interventions, missing evidence, roles, audit, calibration tables) runs without a GPU.
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from c3r.concepts.sparse_coding import project_dictionary, sparse_code  # noqa: E402
from c3r.config import load_config  # noqa: E402
from c3r.detectors.base import COCO80, Detections, FrozenDetector  # noqa: E402
from c3r.explain import Explainer  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


class FakeDetector(FrozenDetector):
    name = "fake"
    interfaces = ["fake"]

    def __init__(self, seed=0):
        rng = np.random.default_rng(seed)
        self.W = rng.normal(size=(80, 48)) * 0.5

    def _z(self, img, box):
        x1, y1, x2, y2 = [int(v) for v in box]
        crop = img[y1:y2, x1:x2].astype(float) / 255
        hs, ws = np.array_split(np.arange(crop.shape[0]), 4), np.array_split(np.arange(crop.shape[1]), 4)
        return np.array([crop[np.ix_(h, w)].mean((0, 1)) for h in hs for w in ws]).ravel()

    def _out(self, Z, box):
        logits = np.atleast_2d(Z) @ self.W.T
        p = np.exp(logits - logits.max(1, keepdims=True)); p /= p.sum(1, keepdims=True)
        return {"probs": p, "obj": np.full(len(p), 0.9), "box": np.tile(box, (len(p), 1))}

    def detect(self, img, boxes=None):
        boxes = self._gt
        Z = np.stack([self._z(img, b) for b in boxes])
        o = self._out(Z, boxes[0])
        return Detections(boxes.copy(), np.full(len(boxes), 0.9), np.array([COCO80[int(np.argmax(p))] for p in o["probs"]]),
                          o["probs"], o["obj"], Z, [tuple(b) for b in boxes], ["fake"] * len(boxes))

    def head(self, handle, Z):
        return self._out(Z, np.array(handle, float))

    def features_at(self, imgs, handle, batch=8):
        Z = np.stack([self._z(im, handle) for im in imgs])
        return Z, self._out(Z, np.array(handle, float))


class FakeCS:
    def __init__(self, d=48, K=6, seed=0):
        rng = np.random.default_rng(seed)
        self.A = rng.normal(size=(16, d)) * 0.5
        self.D = project_dictionary(rng.random((16, K)))
        self.B = rng.normal(size=(d, 16)) * 0.3

    def code(self, iface, Z, lam, n_iter=100):
        H = np.log1p(np.exp(np.atleast_2d(Z) @ self.A.T))
        H /= np.linalg.norm(H, axis=1, keepdims=True) + 1e-8
        return sparse_code(H, self.D, lam, n_iter)

    def BD(self, iface):
        return self.B @ self.D


def _cfg():
    cfg = load_config(ROOT / "configs" / "default.yaml",
                      ["concepts.K=6", "intervention.n_controls=20", "roles.n_boot=100", "intervention.n_replicates=3",
                       "intervention.occlusion_grid=4", "concepts.lambda_1=0.001"])
    return cfg


def test_explainer_end_to_end(tmp_path):
    cfg = _cfg()
    rng = np.random.default_rng(0)
    img = (rng.random((120, 160, 3)) * 255).astype(np.uint8)
    gt = np.array([[20.0, 20, 100, 100]])
    det = FakeDetector()
    det._gt = gt
    cs = FakeCS()
    K = cfg.concepts.K
    pi = {1: np.full(K, 0.9)}
    mu = {1: np.full(K, 0.5)}
    bank = {(-1, k): (rng.random((32, 32, 3)) * 255).astype(np.uint8) for k in range(K)}
    ex = Explainer(det, cs, (pi, mu), {1: {}}, {c: "x" for c in COCO80}, [0], bank, cfg)
    dets, assign, valid, _ = ex.match(img, gt)
    assert valid.all()
    ctx = ex.context(img, dets, assign[0], gt[0], 1, obj_id=7)
    assert ctx["maps"].shape[0] == K and ctx["y_alt"] != 1
    rows = []
    for k in range(K):
        r = ex.explain_pair(ctx, k, "main")
        a = ex.explain_pair(ctx, k, "audit")
        assert r["role"] in ("environmental", "missing", "supporting", "conflicting", "irrelevant", "undetermined")
        assert r["ci_lo"] <= r["aie"] <= r["ci_hi"] + 1e-9
        assert 0.0 <= r["G_minus"] <= 1.0
        rows.append((r, a))
    # main and audit use disjoint streams but must agree on deterministic quantities
    assert all(abs(r["raw"][-1] - a["raw"][-1]) < 1e-9 for r, a in rows)


def test_tables_from_synthetic_rows(tmp_path):
    from c3r.evaluate import table6, table9
    from c3r.pipeline import save
    cfg = _cfg()
    cfg["output_dir"] = str(tmp_path)
    rng = np.random.default_rng(3)
    roles = ["supporting", "conflicting", "missing", "irrelevant", "environmental"]

    def rows(n, split):
        out = []
        for i in range(n):
            aud = roles[rng.integers(5)]
            good = rng.random() < 0.75
            pred = aud if good else ("undetermined" if rng.random() < 0.3 else roles[rng.integers(5)])
            aie = rng.normal()
            out.append(dict(obj_id=i, image_id=i // 4, condition="clean", k=i % 6, aie=aie, ci_lo=aie - 0.1,
                            ci_hi=aie + 0.1 + (0 if good else 0.3), G_minus=0.9 if good else 0.5,
                            var_rep=0.01 if good else 0.05, valid=1.0, rec_M=np.nan, rec_L=np.nan,
                            role=pred, audit_role=aud, audit_valid=1.0, audit_iou_loss=rng.normal() * 0.05,
                            raw=[0, 0, 0, 0, aie], ctrl=[0] * 5, y_ref=1, y_alt=2))
        return out

    for s, n in (("dev", 400), ("cal", 300), ("test", 300)):
        save(rows(n, s), tmp_path / f"explain_{s}_full.pkl")
    macro = table6(cfg)
    assert 0 <= macro["F1"] <= 1
    res = table9(cfg)
    assert np.isfinite(res["ece"])
    assert (tmp_path / "tables" / "table9_calibration.csv").exists()
    txt = (tmp_path / "tables" / "table9_calibration.csv").read_text()
    assert "REPORT" in txt and "ABSTAIN" in txt
