"""Unit tests for the detector-independent parts of C3R (no GPU, no COCO needed).

A synthetic linear "detector head" makes the expected signs of every quantity known in advance.
"""
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from c3r import calibration as cal  # noqa: E402
from c3r.adverse import MechanismScaler, failure_vector, recovery  # noqa: E402
from c3r.concepts.sparse_coding import project_dictionary, sparse_code  # noqa: E402
from c3r.contrast import log_margin, select_alternative  # noqa: E402
from c3r.data.corruptions import CONDITIONS, make_triplet  # noqa: E402
from c3r.interventions import (cross_level_agreement, insertion_gain, integrate_dose, missing_decision,  # noqa: E402
                               missing_deficit, nonsemantic_controls, removal_intervention, sgn_dead)
from c3r.matching import box_iou, match_objects  # noqa: E402
from c3r.metrics import contrastive_fidelity, method_deadzone, role_report  # noqa: E402
from c3r.roles import assign_role  # noqa: E402
from c3r.seeding import stream  # noqa: E402
from c3r.stats import cluster_bootstrap_diff, holm  # noqa: E402


def test_seed_streams_reproducible_and_disjoint():
    a = stream("main", 1, "clean", 3).random(5)
    b = stream("main", 1, "clean", 3).random(5)
    c = stream("audit", 1, "clean", 3).random(5)
    assert np.allclose(a, b) and not np.allclose(a, c)


def test_matching_one_to_one():
    gt = np.array([[0, 0, 10, 10], [20, 20, 30, 30]], float)
    det = np.array([[21, 21, 30, 30], [0, 0, 9, 10], [0, 0, 10, 10.5]], float)
    assign, valid, ious = match_objects(gt, det, 0.5)
    assert len(set(assign)) == 2 and valid.all()
    assert box_iou(gt[:1], gt[:1])[0, 0] == pytest.approx(1.0)


def test_sparse_code_nonneg_and_recovers():
    rng = np.random.default_rng(0)
    D = project_dictionary(rng.random((16, 6)))
    a_true = np.zeros(6); a_true[[1, 4]] = [0.8, 0.5]
    A = sparse_code((D @ a_true)[None], D, lam=1e-3, n_iter=500)
    assert (A >= 0).all()
    assert np.argsort(-A[0])[:2].tolist() in ([1, 4], [4, 1])


# ------------------------------------------------------------------ synthetic detector head
def make_head(d=12, K=4, C=80, seed=0):
    rng = np.random.default_rng(seed)
    BD = rng.normal(size=(d, K))
    W = np.zeros((C, d))
    W[0] = BD[:, 0] * 2.0          # concept 0 supports class 0
    W[1] = BD[:, 1] * 2.0          # concept 1 supports class 1 (the alternative)

    def head(Z):
        Z = np.atleast_2d(Z)
        logits = Z @ W.T
        p = np.exp(logits - logits.max(1, keepdims=True))
        p /= p.sum(1, keepdims=True)
        return {"probs": p, "obj": np.ones(len(Z)), "box": np.tile([10.0, 10, 50, 50], (len(Z), 1))}

    return head, BD


def test_removal_signs_supporting_and_conflicting():
    head, BD = make_head()
    a = np.array([1.0, 1.0, 0.3, 0.0])
    z = BD @ a
    gt = np.array([10.0, 10, 50, 50])
    kw = dict(doses=[0.2, 0.4, 0.6, 0.8, 1.0], n_controls=50, gt_box=gt, d_img=100.0, n_boot=200)
    sup = removal_intervention(z, a, 0, BD, head, 0, 1, rng=stream("t", 0), **kw)
    con = removal_intervention(z, a, 1, BD, head, 0, 1, rng=stream("t", 1), **kw)
    irr = removal_intervention(z, a, 3, BD, head, 0, 1, rng=stream("t", 3), **kw)
    assert sup.aie > 0 and sup.ci[0] > 0
    assert con.aie < 0 and con.ci[1] < 0
    assert abs(irr.aie) < 1e-9
    r = lambda res: assign_role(res.ci, 1.0, False, False, 0.0, 0.01, 0.05, 0.6, 0.05)
    assert (r(sup), r(con), r(irr)) == ("supporting", "conflicting", "irrelevant")


def test_controls_are_nonsemantic_and_energy_matched():
    _, BD = make_head()
    dz = BD @ np.array([0.5, 0, 0, 0])
    C = nonsemantic_controls(dz, BD, 20, stream("c"))
    assert np.allclose(np.linalg.norm(C, axis=1), np.linalg.norm(dz))
    assert np.abs(C @ np.linalg.qr(BD)[0]).max() < 1e-8


def test_integrate_dose_constant():
    assert integrate_dose(np.array([0.2, 0.4, 0.6, 0.8, 1.0]), np.ones(5)) == pytest.approx(0.9, abs=1e-9)


def test_missing_evidence():
    head, BD = make_head()
    a = np.array([0.0, 0.2, 0.0, 0.0])
    d = missing_deficit(a[0], pi_yk=0.8, mu_yk=1.0, pi_0=0.3)
    assert d == pytest.approx(1.0)
    assert missing_deficit(a[0], 0.1, 1.0, 0.3) == 0.0            # prevalence gate
    U = insertion_gain(BD @ a, a, 0, d, BD, head, 0, 1, beta_in=1.0, d_max=1.0)
    assert U > 0 and missing_decision(d, U, 1.0, 0.02, 0.01, 0.6)


def test_role_priority_and_equivalence():
    # interval satisfying both directional and equivalence criteria -> directional
    assert assign_role((0.02, 0.04), 0.9, False, False, 0, 0.01, 0.05, 0.6, 0.05) == "supporting"
    assert assign_role((-0.02, 0.04), 0.9, False, False, 0, 0.01, 0.05, 0.6, 0.05) == "irrelevant"
    assert assign_role((-0.02, 0.09), 0.9, False, False, 0, 0.01, 0.05, 0.6, 0.05) == "undetermined"
    assert assign_role((0.2, 0.3), 0.9, True, False, 0, 0.01, 0.05, 0.6, 0.05) == "missing"
    assert assign_role((0.2, 0.3), 0.9, True, True, 0.2, 0.01, 0.05, 0.6, 0.05) == "environmental"


def test_agreement_counts_neutral_concordance():
    assert cross_level_agreement([0.0, 0.5], [0.001, 0.4], 0.01) == 1.0
    assert sgn_dead([0.02, -0.02, 0.0], 0.01).tolist() == [1, -1, 0]


def test_contrast_and_margin():
    probs = {1: 0.7, 2: 0.2, 3: 0.1}
    sc = {1: "vehicle", 2: "vehicle", 3: "animal"}
    conf = {1: {1: 0.9, 2: 0.08, 3: 0.02}}
    assert select_alternative(1, probs, [1, 2, 3], sc, conf, top_L=2) == 2
    assert log_margin(0.5, 0.5) == pytest.approx(0.0)


def test_calibration_monotone_keeps_auroc_and_risk():
    rng = np.random.default_rng(1)
    X = rng.normal(size=(600, 8))
    y = (X[:, 0] + 0.5 * rng.normal(size=600) > 0).astype(float)
    C = cal.ReliabilityCalibrator(1.0).fit_score(X[:300], y[:300]).fit_platt(X[300:450], y[300:450])
    p0, p1 = C.predict_uncalibrated(X[450:]), C.predict(X[450:])
    assert C.a > 0
    assert cal.auroc(y[450:], p0) == pytest.approx(cal.auroc(y[450:], p1))
    for c in (0.9, 0.75, 0.6):
        assert cal.risk_at_coverage(y[450:], p0, c)[0] == pytest.approx(cal.risk_at_coverage(y[450:], p1, c)[0])
    z = cal.zone_summary(y[450:], p1, 0.4, 0.7, 150)
    assert sum(v["n"] for v in z.values()) == 150


def test_role_report_counts_withheld_as_misses():
    pred = np.array(["supporting", "undetermined", "conflicting", "supporting"])
    aud = np.array(["supporting", "supporting", "conflicting", "irrelevant"])
    per, macro, cov = role_report(pred, aud)
    assert per["supporting"]["P"] == 0.5 and per["supporting"]["R"] == 0.5
    assert cov["withheld"] == 1


def test_cf_and_deadzone():
    dev_aie = np.array([0.0, 0.005, 0.2, -0.3])
    dev_psi = np.array([0.1, -0.2, 3.0, -4.0])
    dE = method_deadzone(dev_aie, dev_psi, 0.01)
    assert dE == pytest.approx(np.quantile(np.abs(dev_psi), 0.5))
    cf, _ = contrastive_fidelity(np.array([0.5, -0.5, 0.0]), 0.01, np.array([1, -1, 1]))
    assert cf == pytest.approx(2 / 3)


def test_bootstrap_and_holm():
    ids = np.repeat(np.arange(50), 4)
    a = np.ones(200); b = np.zeros(200)
    d, ci, p = cluster_bootstrap_diff(ids, a, b, 200, stream("b"))
    assert d == 1.0 and ci[0] == 1.0 and p == 0.0
    assert holm([0.01, 0.04, 0.03]).tolist() == pytest.approx([0.03, 0.06, 0.06])


def test_recovery_and_failure_vector():
    assert recovery(1.2, 0.8, 1.0, 0.05) == pytest.approx(0.5)
    assert np.isnan(recovery(1.0, 0.99, 1.0, 0.05))
    K = 4
    g = failure_vector(dict(a_c=np.array([0.1, 0.8, 0.0, 0.0]), a_a=np.array([0.5, 0.2, 0.0, 0.0]),
                            logp_alt_a=-1.0, logp_alt_r=-2.0, U_plus_a=np.array([0, 0.3, 0, 0.0]),
                            L_c=0.8, L_a=0.6, L_r=0.7, aie_c=np.zeros(K), aie_a=np.zeros(K),
                            var_c=np.zeros(K), var_a=np.ones(K), env=np.array([0]), obj=np.array([1, 2, 3])))
    assert (g >= 0).all() and g[0] > 0 and g[1] > 0 and g[2] > 0 and g[4] > 0
    sc = MechanismScaler().fit(np.abs(np.random.default_rng(0).normal(size=(50, 5))))
    assert sc.predict(g[None] * 100)[0][g > 0].all() and not sc.predict(g[None] * 100)[0][3]


@pytest.mark.parametrize("cond", CONDITIONS)
def test_corruptions_reproducible(cond):
    img = (np.random.default_rng(0).random((64, 80, 3)) * 255).astype(np.uint8)
    t1 = make_triplet(img, cond, 3, stream("x", cond))
    t2 = make_triplet(img, cond, 3, stream("x", cond))
    assert all(np.array_equal(a, b) for a, b in zip(t1, t2))
    assert t1[1].shape == img.shape and t1[2].dtype == np.uint8
    assert not np.array_equal(t1[0], t1[1])
